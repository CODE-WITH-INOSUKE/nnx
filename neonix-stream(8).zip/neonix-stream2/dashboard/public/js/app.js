/* ══════════════════════════════════════════════════════════════
   app.js — Neonix Dashboard global JS
══════════════════════════════════════════════════════════════ */

// ── Sidebar ──────────────────────────────────────────────────
function toggleSidebar() {
  const sb = document.getElementById('sidebar');
  const ov = document.getElementById('overlay');
  if (!sb) return;
  const open = sb.classList.toggle('open');
  ov.classList.toggle('show', open);
  if (open) closeNotifs();
}
function closeSidebar() {
  document.getElementById('sidebar')?.classList.remove('open');
  document.getElementById('overlay')?.classList.remove('show');
}

// ── Notifications ────────────────────────────────────────────
let _notifOpen = false;
const _notifs = [];

function toggleNotifs() {
  _notifOpen = !_notifOpen;
  const panel = document.getElementById('notifPanel');
  const ov    = document.getElementById('overlay');
  if (!panel) return;
  panel.classList.toggle('show', _notifOpen);
  // only show overlay for notifs on mobile
  if (window.innerWidth <= 680) ov.classList.toggle('show', _notifOpen);
  if (_notifOpen) document.getElementById('notifDot')?.classList.remove('show');
}
function closeNotifs() {
  _notifOpen = false;
  document.getElementById('notifPanel')?.classList.remove('show');
}

function addNotif(title, text, type = 'info') {
  const ts = new Date().toLocaleTimeString();
  _notifs.unshift({ title, text, ts, type, unread: true });
  renderNotifs();
  document.getElementById('notifDot')?.classList.add('show');
}

function renderNotifs() {
  const el = document.getElementById('notifList');
  if (!el) return;
  if (!_notifs.length) { el.innerHTML = '<div class="notif-empty">No notifications yet</div>'; return; }
  el.innerHTML = _notifs.map(n => `
    <div class="notif-item${n.unread ? ' unread' : ''}">
      <div class="ni-dot-sm"></div>
      <div class="ni-body">
        <div class="ni-title">${n.title}</div>
        <div class="ni-text">${n.text}</div>
        <div class="ni-time">${n.ts}</div>
      </div>
    </div>`).join('');
}

function clearNotifs() {
  _notifs.length = 0;
  renderNotifs();
  document.getElementById('notifDot')?.classList.remove('show');
}

// ── DOMContentLoaded ─────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  // Close sidebar on overlay click or nav click (mobile)
  document.querySelectorAll('.nav-item').forEach(el => {
    el.addEventListener('click', () => {
      if (window.innerWidth <= 680) closeSidebar();
    });
  });

  // Close notif panel on outside click (desktop)
  document.addEventListener('click', (e) => {
    const panel = document.getElementById('notifPanel');
    const btn   = document.querySelector('.sb-notif-btn');
    if (_notifOpen && panel && !panel.contains(e.target) && !btn?.contains(e.target)) {
      closeNotifs();
    }
  });

  // Auto-dismiss flash messages
  const f = document.querySelector('.flash');
  if (f) {
    setTimeout(() => {
      f.style.transition = 'opacity .4s, max-height .4s';
      f.style.opacity = '0';
      f.style.maxHeight = '0';
      setTimeout(() => f.remove(), 420);
    }, 4500);
  }

  // Keyboard shortcut: Escape closes sidebar + notifs
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') { closeSidebar(); closeNotifs(); }
  });
});

// ── Window resize ────────────────────────────────────────────
window.addEventListener('resize', () => {
  if (window.innerWidth > 680) {
    closeSidebar();
    // close notif overlay on resize to desktop
    if (!_notifOpen) document.getElementById('overlay')?.classList.remove('show');
  }
});

// ── Fetch helpers ────────────────────────────────────────────
async function apiFetch(url, opts = {}) {
  try {
    const r = await fetch(url, opts);
    return await r.json();
  } catch (e) {
    console.error('[apiFetch]', url, e);
    return null;
  }
}

// ── Toast notification (in-page) ────────────────────────────
function showToast(msg, type = 'info') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.style.cssText = 'position:fixed;bottom:20px;right:20px;z-index:9999;display:flex;flex-direction:column;gap:8px;pointer-events:none';
    document.body.appendChild(container);
  }
  const colors = { info: 'var(--acc)', ok: 'var(--green)', err: 'var(--red)', warn: 'var(--yellow)' };
  const toast = document.createElement('div');
  toast.style.cssText = `
    background:var(--surf2);border:1px solid ${colors[type] || colors.info};
    border-radius:var(--r);padding:10px 16px;font-size:.8rem;
    color:var(--text);box-shadow:0 8px 24px rgba(0,0,0,.5);
    animation:slideUp .2s ease;pointer-events:all;
    max-width:300px;font-family:var(--font);
  `;
  toast.textContent = msg;
  container.appendChild(toast);
  setTimeout(() => { toast.style.opacity = '0'; toast.style.transition = 'opacity .3s'; setTimeout(() => toast.remove(), 300); }, 3000);
}

// ── Clipboard helper ─────────────────────────────────────────
function copyToClipboard(text, label = 'Copied') {
  navigator.clipboard.writeText(text).then(() => showToast(`✓ ${label}`, 'ok')).catch(() => {});
}

// ── Confirm helper ───────────────────────────────────────────
function confirmAction(msg, fn) {
  if (confirm(msg)) fn();
}

// Expose globals
window.toggleSidebar = toggleSidebar;
window.closeSidebar  = closeSidebar;
window.toggleNotifs  = toggleNotifs;
window.closeNotifs   = closeNotifs;
window.addNotif      = addNotif;
window.clearNotifs   = clearNotifs;
window.showToast     = showToast;
window.copyToClipboard = copyToClipboard;
window.confirmAction   = confirmAction;
window.apiFetch        = apiFetch;
