/**
 * commands/utility/stream.js
 * Download lowest quality → camera stream.
 * Usage: !stream <youtube url | direct url | local filename>
 */

import { startStream, isYtdlpUrl } from '../../functions/streamUtils.js';
import streamManager, { StreamSession } from '../../functions/streamManager.js';

export default {
  name:        'stream',
  aliases:     ['golive', 'gl', 'cam'],
  category:    'utility',
  description: 'Download (lowest quality) then camera-stream. Use !stream-nd for no-download.',
  usage:       'stream <url | filename>',

  async execute(message, args, client) {
    if (!message.guild) return message.channel.send('```\n❌ Server only.\n```');
    const vc = message.member?.voice?.channel;
    if (!vc) return message.channel.send('```\n❌ Join a voice channel first.\n```');

    if (!args.length) {
      return message.channel.send([
        '```',
        'Usage:',
        '  !stream <youtube url>         ← downloads first',
        '  !stream-nd <youtube url>      ← streams directly (no download)',
        '  !streamlocal <filename>       ← stream from ./video/',
        '  !streamfiles                  ← list ./video/',
        '```',
      ].join('\n'));
    }

    const url     = args[0];
    const guildId = message.guild.id;

    if (streamManager.has(guildId)) await streamManager.destroy(guildId, client);

    const isYt = isYtdlpUrl(url);
    const statusMsg = await message.channel.send([
      '```',
      '╭─[ STREAM ]────────────────────────╮',
      isYt ? '  ⬇️  Downloading (lowest quality)...' : '  ⏳ Connecting...',
      '╰──────────────────────────────────╯',
      '```',
    ].join('\n'));

    let lastEdit = 0;
    const onProgress = (pct) => {
      const now = Date.now();
      if (now - lastEdit < 4000) return;
      lastEdit = now;
      statusMsg.edit([
        '```',
        '╭─[ STREAM ]────────────────────────╮',
        `  ⬇️  Downloading... ${pct}%`,
        '╰──────────────────────────────────╯',
        '```',
      ].join('\n')).catch(() => {});
    };

    try {
      const { streamer, command, title, done } = await startStream(
        client, guildId, vc.id, url, isYt ? onProgress : undefined
      );

      const session       = new StreamSession(guildId);
      session.channelId   = vc.id;
      session.url         = url;
      session.title       = title;
      session.streamer    = streamer;
      session.command     = command;
      session.textChannel = message.channel;
      streamManager.set(guildId, session);

      done.then(async () => {
        if (!streamManager.has(guildId)) return;
        const s = streamManager.get(guildId);
        await streamManager.destroy(guildId, client);
        message.channel.send([
          '```',
          '╭─[ STREAM ENDED ]──────────────────╮',
          `  📺 ${s?.title ?? url}`,
          '  ✅ Finished.',
          '╰──────────────────────────────────╯',
          '```',
        ].join('\n')).catch(() => {});
      }).catch(() => {});

      await statusMsg.edit([
        '```',
        '╭─[ STREAMING ]─────────────────────╮',
        `  📺 ${title}`,
        `  🔊 ${vc.name}`,
        '  📷 Camera ON · 480p · 24fps',
        '  💾 Downloaded mode',
        '',
        '  !streamstop  — stop & leave VC',
        '  !streamnp    — stream info',
        '╰──────────────────────────────────╯',
        '```',
      ].join('\n'));

    } catch (err) {
      console.error('[stream]', err);
      await streamManager.destroy(guildId, client).catch(() => {});
      await statusMsg.edit(`\`\`\`\n❌ ${err.message}\n\`\`\``);
    }

    if (message.deletable) message.delete().catch(() => {});
  },
};
