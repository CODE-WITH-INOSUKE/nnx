/**
 * commands/utility/streamlocal.js
 * Stream a local file from ./video/ in camera mode.
 * Usage: !streamlocal <filename>
 *        !streamlocal           ← list files
 */

import path from 'path';
import { startStream, listLocalVideos, VIDEO_DIR } from '../../functions/streamUtils.js';
import streamManager, { StreamSession } from '../../functions/streamManager.js';

export default {
  name:        'streamlocal',
  aliases:     ['sl', 'localstream', 'streamfile'],
  category:    'utility',
  description: 'Stream a local file from ./video/ in camera mode',
  usage:       'streamlocal <filename>',

  async execute(message, args, client) {
    if (!message.guild) return message.channel.send('```\n❌ Server only.\n```');

    if (!args.length) {
      const files = listLocalVideos();
      if (!files.length) {
        return message.channel.send([
          '```',
          '╭─[ VIDEO FOLDER ]──────────────────╮',
          '  📭 No videos yet.',
          '  Use !stream <yt url> to download one.',
          '╰──────────────────────────────────╯',
          '```',
        ].join('\n'));
      }
      const list = files.map((f, i) =>
        `  ${i + 1}. ${f.name}  (${(f.size / 1024 / 1024).toFixed(1)} MB)`
      ).join('\n');
      return message.channel.send([
        '```',
        '╭─[ LOCAL VIDEOS ]──────────────────╮',
        list,
        '',
        '  Usage: !streamlocal <filename>',
        '╰──────────────────────────────────╯',
        '```',
      ].join('\n'));
    }

    const vc = message.member?.voice?.channel;
    if (!vc) return message.channel.send('```\n❌ Join a voice channel first.\n```');

    const filename = args.join(' ');
    const filePath = path.join(VIDEO_DIR, filename);
    const guildId  = message.guild.id;

    if (streamManager.has(guildId)) await streamManager.destroy(guildId, client);

    const statusMsg = await message.channel.send([
      '```',
      '╭─[ STREAM ]────────────────────────╮',
      `  ⏳ Loading ${filename}...`,
      '╰──────────────────────────────────╯',
      '```',
    ].join('\n'));

    try {
      const { streamer, command, title, done } = await startStream(
        client, guildId, vc.id, filePath
      );

      const session       = new StreamSession(guildId);
      session.channelId   = vc.id;
      session.url         = filePath;
      session.title       = title;
      session.streamer    = streamer;
      session.command     = command;
      session.textChannel = message.channel;
      streamManager.set(guildId, session);

      done.then(async () => {
        if (!streamManager.has(guildId)) return;
        const s = streamManager.get(guildId);
        await streamManager.destroy(guildId, client);
        message.channel.send([
          '```',
          '╭─[ STREAM ENDED ]──────────────────╮',
          `  📁 ${s?.title ?? filename}`,
          '  ✅ Finished.',
          '╰──────────────────────────────────╯',
          '```',
        ].join('\n')).catch(() => {});
      }).catch(() => {});

      await statusMsg.edit([
        '```',
        '╭─[ STREAMING LOCAL ]───────────────╮',
        `  📁 ${title}`,
        `  🔊 ${vc.name}`,
        '  📷 Camera ON · 480p · 24fps',
        '',
        '  !streamstop  — stop & leave VC',
        '  !streamnp    — stream info',
        '╰──────────────────────────────────╯',
        '```',
      ].join('\n'));

    } catch (err) {
      console.error('[streamlocal]', err);
      await streamManager.destroy(guildId, client).catch(() => {});
      await statusMsg.edit(`\`\`\`\n❌ ${err.message}\n\`\`\``);
    }

    if (message.deletable) message.delete().catch(() => {});
  },
};
