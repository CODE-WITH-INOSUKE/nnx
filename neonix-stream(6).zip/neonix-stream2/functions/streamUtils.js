/**
 * streamUtils.js
 * Streaming via @dank074/discord-video-stream (latest).
 *
 * Official API (from npm docs):
 *   import { prepareStream, playStream, Utils, Streamer, Encoders } from "@dank074/discord-video-stream"
 *   const streamer = new Streamer(client)
 *   await streamer.joinVoice(guildId, channelId)
 *   client.signalVideo(guildId, channelId, true)        // camera mode
 *   const { command, output } = prepareStream(url, { encoder, height, frameRate, bitrateVideo, ... })
 *   await playStream(output, streamer, { type: 'camera' | 'go-live' })
 *
 * prepareStream accepts:
 *   - A direct video URL (https://...)   ← used by !stream-nd (no-download)
 *   - A local file path                  ← used by !stream (after yt-dlp download) / !streamlocal
 *
 * !stream-nd:  yt-dlp -g → get direct CDN URL → pass to prepareStream (no file saved)
 * !stream:     yt-dlp download lowest quality → ./video/<id>.mp4 → pass file path
 * !streamlocal: pass local file path directly
 */

import { execFile, spawn }  from 'child_process';
import path                 from 'path';
import fs                   from 'fs';
import { fileURLToPath }    from 'url';

// -- library imports with safe fallback for Encoders --
import {
  Streamer,
  prepareStream,
  playStream,
  Utils,
  Encoders,
} from '@dank074/discord-video-stream';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const YTDLP_BIN = path.join(__dirname, '..', 'yt-dlp');
export const VIDEO_DIR = path.join(__dirname, '..', 'video');

if (!fs.existsSync(VIDEO_DIR)) fs.mkdirSync(VIDEO_DIR, { recursive: true });

// ── yt-dlp chmod ─────────────────────────────────────────────────────────────

function ensureExecutable() {
  try { fs.chmodSync(YTDLP_BIN, 0o755); return true; } catch { return false; }
}
const ytdlpReady = ensureExecutable();
console.log(`[Stream] yt-dlp: ${ytdlpReady ? YTDLP_BIN + ' ✓' : 'NOT FOUND — ' + YTDLP_BIN}`);

// ── source detection ──────────────────────────────────────────────────────────

const YTDLP_RE = /youtu(\.be|be\.com)|twitch\.tv|soundcloud\.com|tiktok\.com|dailymotion\.com|vimeo\.com/i;

export function isYtdlpUrl(str) {
  try { return YTDLP_RE.test(new URL(str).hostname); }
  catch { return false; }
}

export function listLocalVideos() {
  try {
    return fs.readdirSync(VIDEO_DIR)
      .filter(f => /\.(mp4|mkv|webm|avi|mov)$/i.test(f))
      .map(f => ({
        name: f,
        path: path.join(VIDEO_DIR, f),
        size: fs.statSync(path.join(VIDEO_DIR, f)).size,
      }));
  } catch { return []; }
}

// ── yt-dlp: get direct stream URL (no download) ───────────────────────────────

/**
 * Run yt-dlp -g to get a direct playable URL.
 * Returns { streamUrl, title }
 */
export function getDirectUrl(inputUrl) {
  ensureExecutable();
  return new Promise((resolve, reject) => {
    console.log(`[yt-dlp] Getting direct URL for: ${inputUrl}`);

    // best single-file format so ffmpeg gets one clean https URL
    const args = [
      '--no-playlist',
      '--no-warnings',
      '-f', 'best[ext=mp4]/best',
      '--get-url',
      '--get-title',
      inputUrl,
    ];

    execFile(YTDLP_BIN, args, { maxBuffer: 4 * 1024 * 1024, timeout: 30000 }, (err, stdout, stderr) => {
      if (err) {
        console.error('[yt-dlp] error:', stderr?.trim() || err.message);
        return reject(new Error(`yt-dlp failed: ${stderr?.trim().slice(0, 200) || err.message}`));
      }

      const lines = stdout.trim().split('\n').filter(Boolean);
      console.log(`[yt-dlp] output (${lines.length} lines):`, lines.slice(0, 3));

      if (lines.length < 2) {
        return reject(new Error(`yt-dlp returned too few lines (${lines.length}). Output: ${stdout.slice(0, 200)}`));
      }

      // yt-dlp outputs: title first, then URL(s)
      const title     = lines[0];
      const streamUrl = lines[1];

      console.log(`[yt-dlp] title: ${title}`);
      console.log(`[yt-dlp] url: ${streamUrl.slice(0, 80)}...`);
      resolve({ streamUrl, title });
    });
  });
}

// ── yt-dlp: download lowest quality ──────────────────────────────────────────

/**
 * Download lowest quality to ./video/<id>.mp4
 * Returns { filePath, title }
 */
export function downloadWithYtdlp(inputUrl, onProgress) {
  ensureExecutable();
  return new Promise((resolve, reject) => {
    console.log(`[yt-dlp] Fetching info: ${inputUrl}`);

    execFile(
      YTDLP_BIN,
      ['--no-playlist', '--no-warnings', '--get-title', '--get-id', inputUrl],
      { maxBuffer: 2 * 1024 * 1024, timeout: 20000 },
      (err, stdout) => {
        const lines = (stdout || '').trim().split('\n').filter(Boolean);
        const title = lines[0] || 'Unknown';
        const id    = lines[1] || `dl_${Date.now()}`;
        console.log(`[yt-dlp] Title="${title}" id=${id}`);

        // Cache check
        const exts   = ['mp4', 'webm', 'mkv'];
        const cached = exts.map(e => path.join(VIDEO_DIR, `${id}.${e}`)).find(f => fs.existsSync(f));
        if (cached) {
          console.log(`[yt-dlp] Cache hit: ${cached}`);
          return resolve({ filePath: cached, title });
        }

        // Download lowest quality
        const dlArgs = [
          '--no-playlist', '--no-warnings',
          '-f', 'worstvideo[ext=mp4]+worstaudio[ext=m4a]/worst[ext=mp4]/worst',
          '--merge-output-format', 'mp4',
          '-o', path.join(VIDEO_DIR, '%(id)s.%(ext)s'),
          '--newline',
          inputUrl,
        ];

        console.log('[yt-dlp] Downloading lowest quality...');
        const proc = spawn(YTDLP_BIN, dlArgs, { stdio: ['ignore', 'pipe', 'pipe'] });

        proc.stdout.on('data', chunk => {
          for (const line of chunk.toString().split('\n').filter(l => l.trim())) {
            console.log(`[yt-dlp] ${line}`);
            if (typeof onProgress === 'function') {
              const m = line.match(/(\d+\.?\d*)%/);
              if (m) onProgress(m[1]);
            }
          }
        });
        proc.stderr.on('data', d => {
          const msg = d.toString().trim();
          if (msg) console.error(`[yt-dlp err] ${msg}`);
        });
        proc.on('error', e => reject(new Error(`yt-dlp spawn error: ${e.message}`)));
        proc.on('close', code => {
          console.log(`[yt-dlp] exit ${code}`);
          if (code !== 0) return reject(new Error(`yt-dlp exited with code ${code}`));

          const found = exts.map(e => path.join(VIDEO_DIR, `${id}.${e}`)).find(f => fs.existsSync(f));
          if (found) {
            console.log(`[yt-dlp] Done: ${found}`);
            return resolve({ filePath: found, title });
          }

          // Fallback: newest file
          try {
            const files = fs.readdirSync(VIDEO_DIR)
              .map(f => ({ f, t: fs.statSync(path.join(VIDEO_DIR, f)).mtimeMs }))
              .sort((a, b) => b.t - a.t);
            if (files.length) return resolve({ filePath: path.join(VIDEO_DIR, files[0].f), title });
          } catch {}
          reject(new Error('Download finished but file not found in ./video/'));
        });
      }
    );
  });
}

// ── build prepareStream options ───────────────────────────────────────────────

function buildStreamOptions(height, frameRate, bitrateVideo, bitrateVideoMax) {
  const videoCodec = Utils.normalizeVideoCodec('H264');

  // Try Encoders.software() (GitHub/latest builds)
  // Fall back to h26xPreset top-level option (npm stable)
  if (typeof Encoders?.software === 'function') {
    const encoder = Encoders.software({
      x264: { preset: 'ultrafast', tune: 'zerolatency' },
    });
    return { encoder, height, frameRate, bitrateVideo, bitrateVideoMax, videoCodec, includeAudio: true, minimizeLatency: true, hardwareAcceleratedDecoding: false };
  }

  // Fallback: h26xPreset top-level (npm stable)
  return { h26xPreset: 'ultrafast', height, frameRate, bitrateVideo, bitrateVideoMax, videoCodec, includeAudio: true, minimizeLatency: true, hardwareAcceleratedDecoding: false };
}

// ── core stream function ──────────────────────────────────────────────────────

/**
 * Join VC and start streaming.
 * source = local file path OR direct https URL
 * type   = 'camera' | 'go-live'
 */
async function _stream(client, guildId, channelId, source, type = 'camera') {
  console.log(`[Stream] joinVoice guild=${guildId} ch=${channelId}`);
  const streamer = new Streamer(client);
  await streamer.joinVoice(guildId, channelId);
  console.log('[Stream] Voice joined ✓');

  // Signal webcam on for camera mode
  try { client.signalVideo(guildId, channelId, true); console.log('[Stream] signalVideo ✓'); }
  catch (e) { console.warn('[Stream] signalVideo unavailable:', e.message); }

  // Settle before sending packets
  await new Promise(r => setTimeout(r, 1000));

  const opts = buildStreamOptions(480, 24, 800, 1200);
  console.log(`[Stream] prepareStream source=${String(source).slice(0, 80)}`);
  const { command, output } = prepareStream(source, opts);

  command.on('error', (e, _out, stderr) => console.error('[ffmpeg]', e.message, stderr?.slice(0, 200)));
  command.on('end',   ()               => console.log('[ffmpeg] finished'));

  console.log(`[Stream] playStream type=${type}`);
  const done = playStream(output, streamer, { type });

  done.then(() => console.log('[Stream] ✓ ended')).catch(e => console.error('[Stream] ✗', e?.message));

  return { streamer, command, done };
}

// ── public API ────────────────────────────────────────────────────────────────

/**
 * !stream  — download first, then stream local file (camera mode)
 */
export async function startStream(client, guildId, channelId, inputUrl, onProgress) {
  console.log(`\n[Stream:download] input=${inputUrl}`);

  let source, title;

  if (isYtdlpUrl(inputUrl)) {
    const dl = await downloadWithYtdlp(inputUrl, onProgress);
    source   = dl.filePath;
    title    = dl.title;
  } else if (!inputUrl.startsWith('http')) {
    // Local file — resolve from video dir if bare name
    const candidate = path.isAbsolute(inputUrl) ? inputUrl : path.join(VIDEO_DIR, inputUrl);
    if (!fs.existsSync(candidate)) throw new Error(`File not found: ${candidate}`);
    source = candidate;
    title  = path.basename(candidate, path.extname(candidate));
  } else {
    source = inputUrl;
    title  = inputUrl;
  }

  console.log(`[Stream:download] source=${source}`);
  const { streamer, command, done } = await _stream(client, guildId, channelId, source, 'camera');
  return { streamer, command, title, done };
}

/**
 * !stream-nd  — get direct URL via yt-dlp, stream without downloading (camera mode)
 */
export async function startStreamNd(client, guildId, channelId, inputUrl) {
  console.log(`\n[Stream:nd] input=${inputUrl}`);

  let source, title;

  if (isYtdlpUrl(inputUrl)) {
    const resolved = await getDirectUrl(inputUrl);
    source = resolved.streamUrl;
    title  = resolved.title;
  } else {
    // Direct URL passed — stream as-is
    source = inputUrl;
    title  = inputUrl;
  }

  console.log(`[Stream:nd] source=${source.slice(0, 80)}...`);
  const { streamer, command, done } = await _stream(client, guildId, channelId, source, 'camera');
  return { streamer, command, title, done };
}

// ── cleanup ───────────────────────────────────────────────────────────────────

export async function cleanupStream(client, guildId, channelId, streamer, command) {
  console.log(`[Stream] cleanup guild=${guildId}`);
  try { command?.kill('SIGKILL'); }             catch {}
  try { await streamer?.stopStream(); }         catch {}
  try { client.signalVideo(guildId, channelId, false); } catch {}
}
