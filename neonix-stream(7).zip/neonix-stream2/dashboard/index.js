import startRouter from './router.js';
export default function initDashboard(ctx) { startRouter(ctx); }
