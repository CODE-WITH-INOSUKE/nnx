/* ── Sidebar toggle ── */
function toggleSidebar() {
  const sb = document.getElementById('sidebar');
  const ov = document.getElementById('overlay');
  if (!sb) return;
  const isOpen = sb.classList.toggle('open');
  ov.classList.toggle('show', isOpen);
  // Close notif panel if open
  if (isOpen) closeNotifs();
}

/* ── Close sidebar ── */
function closeSidebar() {
  document.getElementById('sidebar')?.classList.remove('open');
  document.getElementById('overlay')?.classList.remove('show');
}

/* ── Auto-close sidebar on nav click (mobile) ── */
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('overlay')?.addEventListener('click', () => {
    closeSidebar();
    closeNotifs();
  });
  document.querySelectorAll('.nav-item').forEach(el => {
    el.addEventListener('click', () => {
      if (window.innerWidth <= 680) closeSidebar();
    });
  });
  // Auto-dismiss flash messages
  const f = document.querySelector('.flash');
  if (f) setTimeout(() => {
    f.style.transition = 'opacity .4s';
    f.style.opacity = '0';
    setTimeout(() => f.remove(), 400);
  }, 4000);
});

/* ── Window resize: close sidebar if resized to desktop ── */
window.addEventListener('resize', () => {
  if (window.innerWidth > 680) closeSidebar();
});

/* ─────────────────────────────────────────────────────────────────────────────
   NOTIFICATION SYSTEM
───────────────────────────────────────────────────────────────────────────── */
let _notifOpen = false;
const _notifs = [];

function toggleNotifs() {
  _notifOpen = !_notifOpen;
  const panel = document.getElementById('notifPanel');
  const ov = document.getElementById('overlay');
  if (!panel) return;
  panel.classList.toggle('show', _notifOpen);
  ov.classList.toggle('show', _notifOpen);
  if (_notifOpen) {
    // mark as read — hide dot
    document.getElementById('notifDot')?.classList.remove('show');
  }
}

function closeNotifs() {
  if (!_notifOpen) return;
  _notifOpen = false;
  document.getElementById('notifPanel')?.classList.remove('show');
}

function clearNotifs() {
  _notifs.length = 0;
  renderNotifs();
  document.getElementById('notifDot')?.classList.remove('show');
}

function renderNotifs() {
  const list = document.getElementById('notifList');
  if (!list) return;
  if (!_notifs.length) {
    list.innerHTML = '<div class="notif-empty">No notifications yet</div>';
    return;
  }
  list.innerHTML = _notifs.map(n => `
    <div class="notif-item unread">
      <div class="ni-body">
        <div class="ni-title">🔔 ${_esc(n.author)} mentioned you</div>
        <div class="ni-text">${_esc(n.content)}</div>
        <div class="ni-time">${n.time} · ${_esc(n.guild)} #${_esc(n.channel)}</div>
      </div>
    </div>`).join('');
}

function _esc(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

/* Poll for new mentions every 3 seconds */
const _seenNotifIds = new Set();
async function pollNotifs() {
  try {
    const r = await fetch('/api/notifications');
    const data = await r.json();
    if (!data.mentions?.length) return;
    let hasNew = false;
    for (const m of data.mentions) {
      if (!_seenNotifIds.has(m.id)) {
        _seenNotifIds.add(m.id);
        _notifs.unshift(m);
        hasNew = true;
      }
    }
    if (_notifs.length > 50) _notifs.length = 50;
    if (hasNew) {
      renderNotifs();
      if (!_notifOpen) document.getElementById('notifDot')?.classList.add('show');
    }
  } catch {}
}
setInterval(pollNotifs, 3000);
