import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';
import { loadConfig as loadRpcConfig, saveConfig as saveRpcConfig, setRichPresence } from '../commands/tools/rpc.js';
import { loadReactionData, saveReactionData } from '../functions/autoReaction.js';
import { loadAfk, saveAfk, loadAfkLogs, saveAfkLogs } from '../functions/afk.js';

const __require = createRequire(import.meta.url);
const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);
const DB_ROOT    = path.join(__dirname, '..', 'database');
const PUBLIC     = path.join(__dirname, 'public');
const VIEWS      = path.join(__dirname, 'views');

// ── Auth ──────────────────────────────────────────────────────────────────────
const SESSIONS = new Set();
const rndTok = () => Math.random().toString(36).slice(2) + Date.now().toString(36);
function parseCookies(req) {
  const out = {};
  for (const p of (req.headers.cookie||'').split(';')) { const i=p.indexOf('='); if(i>0) out[p.slice(0,i).trim()]=p.slice(i+1).trim(); }
  return out;
}
const isAuthed = (req) => SESSIONS.has(parseCookies(req).nx_session);

// ── Mention store (for live notifications) ────────────────────────────────────
const mentionLog = [];

// ── Helpers ───────────────────────────────────────────────────────────────────
const readBody = (req) => new Promise(r => { let b=''; req.on('data',c=>b+=c); req.on('end',()=>r(b)); });
function parseForm(body) {
  const o={};
  for (const p of body.split('&')) { const i=p.indexOf('='); if(i>0) o[decodeURIComponent(p.slice(0,i))]=decodeURIComponent(p.slice(i+1).replace(/\+/g,' ')); }
  return o;
}
const isCdn = (u) => { try { return new URL(u).hostname==='cdn.discordapp.com'; } catch { return false; } };
function rj(f,d={}) { try { return JSON.parse(fs.readFileSync(path.join(DB_ROOT,f),'utf8')); } catch { return d; } }
function wj(f,d) { fs.writeFileSync(path.join(DB_ROOT,f),JSON.stringify(d,null,2)); }
const esc = (s) => String(s??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
function view(name) { return fs.readFileSync(path.join(VIEWS,name),'utf8'); }

// ── Music helper ──────────────────────────────────────────────────────────────
function getMusicStatus(client,lavalink,queueManager,voiceStates) {
  const base={connected:!!lavalink,isPlaying:false,isConnectedToVoice:false,activeGuildId:null,guildName:'',guildIcon:null,channelName:'',nowPlaying:null,position:0,duration:0,queue:[],queueCount:0};
  for(const [gId,q] of queueManager.getAll()) {
    if(!q.nowPlaying) continue;
    const g=client.guilds.cache.get(gId);
    const info=q.nowPlaying.info;
    let cover='https://i.imgur.com/2ce2t5e.png';
    if(info.sourceName==='youtube'||info.uri?.includes('youtube')) cover=`https://img.youtube.com/vi/${info.identifier}/maxresdefault.jpg`;
    else if(info.artworkUrl) cover=info.artworkUrl;
    let pos=q.position||0;
    if(q.lastUpdate&&!q.paused) { pos+=Date.now()-q.lastUpdate; if(pos>info.length) pos=info.length; }
    return{...base,isPlaying:true,activeGuildId:gId,guildName:g?.name||`Guild ${gId}`,guildIcon:g?.iconURL({dynamic:true,size:128})||null,nowPlaying:{title:info.title,author:info.author,cover,url:info.uri},position:pos,duration:info.length,queue:q.songs.map(s=>({title:s.info.title,author:s.info.author,cover:s.info.artworkUrl||cover})),queueCount:q.songs.length};
  }
  for(const [gId] of client.guilds.cache) {
    if(voiceStates[gId]?.channelId) { const g=client.guilds.cache.get(gId); return{...base,isConnectedToVoice:true,activeGuildId:gId,guildName:g?.name||'',guildIcon:g?.iconURL({dynamic:true})}; }
  }
  return base;
}
const clonerState={isRunning:false,logs:[],stats:{}};

// ── NAV definition ────────────────────────────────────────────────────────────
const NAV=[
  {s:'MAIN',    id:'home',    href:'/',         label:'Overview',      i:'<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>'},
  {s:'MAIN',    id:'account', href:'/account',  label:'Account',       i:'<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>'},
  {s:'MAIN',    id:'guilds',  href:'/guilds',   label:'Servers',       i:'<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>'},
  {s:'MAIN',    id:'rpc',     href:'/rpc',      label:'Rich Presence',  i:'<circle cx="12" cy="12" r="10"/><polygon points="10 8 16 12 10 16 10 8"/>'},
  {s:'MAIN',    id:'ai',      href:'/ai',       label:'AI Config',      i:'<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>'},
  {s:'MAIN',    id:'aichat',  href:'/aichat',   label:'AI Chat',        i:'<path d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 0 1-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>'},
  {s:'MAIN',    id:'codeagent',href:'/codeagent',label:'Code Agent',   i:'<polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/>'},
  {s:'MAIN',    id:'afk',     href:'/afk',      label:'AFK System',     i:'<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/>'},
  {s:'MAIN',    id:'reaction',href:'/reaction', label:'Auto Reaction',  i:'<circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/>'},
  {s:'MAIN',    id:'discordchat',href:'/discordchat',label:'Server Chat',   i:'<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>'},
    {s:'FEATURES',id:'music',   href:'/music',    label:'Music Player',   i:'<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>'},
  {s:'FEATURES',id:'cloner',  href:'/cloner',   label:'Server Cloner',  i:'<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>'},
  {s:'FEATURES',id:'quests',  href:'/quests',   label:'Quest Terminal', i:'<polyline points="4 17 10 11 4 5"/><line x1="12" y1="19" x2="20" y2="19"/>'},
  {s:'FEATURES',id:'imggen',  href:'/imggen',   label:'Image Gen',      i:'<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/>'},
  {s:'SYSTEM',  id:'commands',href:'/commands', label:'Commands',       i:'<polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/>'},
  {s:'SYSTEM',  id:'logs',    href:'/logs',     label:'Activity Logs',  i:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/>'},
  {s:'SYSTEM',  id:'settings',href:'/settings', label:'Settings',       i:'<circle cx="12" cy="12" r="3"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M4.93 4.93a10 10 0 0 0 0 14.14"/>'},
];

// ── Layout (reads from layout.html) ──────────────────────────────────────────
function layout(pageId,title,username,body,flash='') {
  const secs={};
  for(const n of NAV) { if(!secs[n.s]) secs[n.s]=[]; secs[n.s].push(n); }
  const svg = (d) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
  const navHtml = Object.entries(secs).map(([s,items])=>`
    <div class="sb-section">
      <div class="sb-lbl">${s}</div>
      ${items.map(n=>`<a href="${n.href}" class="nav-item${pageId===n.id?' active':''}">${svg(n.i)}${n.label}</a>`).join('')}
    </div>`).join('');
  const tmpl = view('layout.html');
  return tmpl
    .replace('{{TITLE}}',esc(title))
    .replace('{{PAGE_ID}}',pageId)
    .replace(/{{USERNAME}}/g,esc(username))
    .replace('{{NAV}}',navHtml)
    .replace('{{FLASH}}',flash?`<div class="flash flash-ok">${esc(flash)}</div>`:'')
    .replace('{{BODY}}',body);
}

// ── Main export ───────────────────────────────────────────────────────────────
export default function startRouter({client,lavalink,queueManager,voiceStates}) {
  const PORT = parseInt(process.env.DASH_PORT||'3000',10);

  // Hook mention events for live notifications
  client.on('messageCreate', msg => {
    if(!client.user) return;
    if(msg.author.id===client.user.id) return;
    if(!msg.mentions.has(client.user.id)) return;
    mentionLog.unshift({
      id: `${msg.id}`,
      author: msg.author.tag,
      content: msg.content.replace(/<@!?\d+>/g,'').trim().slice(0,120),
      guild: msg.guild?.name||'DM',
      channel: msg.channel?.name||'DM',
      link: msg.url,
      time: new Date().toLocaleTimeString()
    });
    if(mentionLog.length>100) mentionLog.length=100;
  });

  http.createServer(async(req,res) => {
    const rawUrl=req.url||'/';
    const url=rawUrl.split('?')[0];
    const qs=Object.fromEntries(new URLSearchParams(rawUrl.includes('?')?rawUrl.slice(rawUrl.indexOf('?')+1):''));
    const method=req.method;
    const user=client.user?.username||'—';

    const html=(b,code=200)=>{ res.writeHead(code,{'Content-Type':'text/html;charset=utf-8'}); res.end(b); };
    const json=(d,code=200)=>{ res.writeHead(code,{'Content-Type':'application/json'}); res.end(JSON.stringify(d)); };
    const redir=(loc,hdr={})=>{ res.writeHead(302,{Location:loc,...hdr}); res.end(); };
    const pg=(id,title,body,flash='')=>html(layout(id,title,user,body,flash));

    // Static files
    if(url.startsWith('/css/')||url.startsWith('/js/')) {
      const fp=path.join(PUBLIC,url);
      if(!fs.existsSync(fp)){res.writeHead(404);return res.end('Not found');}
      const ext=path.extname(fp);
      res.writeHead(200,{'Content-Type':ext==='.css'?'text/css':'application/javascript'});
      return res.end(fs.readFileSync(fp));
    }

    // Login
    if(url==='/login') {
      if(method==='GET') return html(view('login.html').replace('{{ERR}}',''));
      if(method==='POST') {
        const form=parseForm(await readBody(req));
        if(form.username===(process.env.DASH_USER||'admin')&&form.password===(process.env.DASH_PASS||'neonix')) {
          const tok=rndTok(); SESSIONS.add(tok);
          return redir('/',{'Set-Cookie':`nx_session=${tok}; HttpOnly; Path=/; Max-Age=86400; SameSite=Lax`});
        }
        return html(view('login.html').replace('{{ERR}}','<div class="flash flash-err">Invalid username or password.</div>'),401);
      }
    }
    if(url==='/logout') {
      SESSIONS.delete(parseCookies(req).nx_session);
      return redir('/login',{'Set-Cookie':'nx_session=; Max-Age=0; Path=/'});
    }
    if(!isAuthed(req)) return redir('/login');

    // ── APIs ──────────────────────────────────────────────────────────────────

    // Notifications
    if(method==='GET'&&url==='/api/notifications') return json({mentions:mentionLog});

    // AI Chat
    if(method==='POST'&&url==='/api/ai/chat') {
      try {
        const {message:msg,provider='groq',history=[]}=JSON.parse(await readBody(req));
        let sys='You are a helpful AI assistant.';
        try{sys=fs.readFileSync(path.join(DB_ROOT,'personality.txt'),'utf8');}catch{}
        const messages=[{role:'system',content:sys},...history.slice(-20),{role:'user',content:msg}];
        let reply='';
        const hdrs={'Content-Type':'application/json'};
        if(provider==='nim'){
          const r=await fetch('https://integrate.api.nvidia.com/v1/chat/completions',{method:'POST',headers:{...hdrs,Authorization:`Bearer ${process.env.NVIDIA_NIM_API_KEY}`},body:JSON.stringify({model:'meta/llama-3.3-70b-instruct',messages,temperature:.7,max_tokens:1024})});
          reply=(await r.json()).choices?.[0]?.message?.content||'No response.';
        } else if(provider==='openrouter'){
          const r=await fetch('https://openrouter.ai/api/v1/chat/completions',{method:'POST',headers:{...hdrs,Authorization:`Bearer ${process.env.OPENROUTER_API_KEY}`,'HTTP-Referer':'https://neonix.local','X-Title':'Neonix'},body:JSON.stringify({model:'openai/gpt-oss-120b:free',messages,max_tokens:1024,temperature:.7})});
          reply=(await r.json()).choices?.[0]?.message?.content||'No response.';
        } else {
          const r=await fetch('https://api.groq.com/openai/v1/chat/completions',{method:'POST',headers:{...hdrs,Authorization:`Bearer ${process.env.GROQ_API_KEY}`},body:JSON.stringify({model:'llama-3.3-70b-versatile',messages,temperature:.7,max_tokens:1024,stream:false})});
          reply=(await r.json()).choices?.[0]?.message?.content||'No response.';
        }
        return json({reply});
      } catch(e){return json({reply:`Error: ${e.message}`},500);}
    }

    // Code Agent (streaming via SSE or buffered)
    if(method==='POST'&&url==='/api/codeagent') {
      try {
        const {prompt}=JSON.parse(await readBody(req));
        if(!prompt) return json({error:'No prompt'},400);
        if(!process.env.NVIDIA_NIM_API_KEY) return json({error:'NVIDIA_NIM_API_KEY not set'},400);
        const { default: OpenAI } = await import('openai');
        const openai = new OpenAI({ apiKey: process.env.NVIDIA_NIM_API_KEY, baseURL:'https://integrate.api.nvidia.com/v1' });
        let thinking='', content='';
        const stream = await openai.chat.completions.create({
          model:'z-ai/glm5',
          messages:[{role:'user',content:`You are an expert programmer. The user wants you to: ${prompt}\n\nWrite complete, working code. For each file, start with a comment: // FILE: filename.ext\nThen write the code. Separate multiple files clearly.`}],
          temperature:1,top_p:1,max_tokens:16384,
          chat_template_kwargs:{enable_thinking:true,clear_thinking:false},
          stream:true
        });
        for await(const chunk of stream) {
          const r=chunk.choices[0]?.delta?.reasoning_content;
          if(r) thinking+=r;
          content+=chunk.choices[0]?.delta?.content||'';
        }
        return json({thinking,content});
      } catch(e){return json({error:e.message},500);}
    }

    // Code Agent via Discord command
    if(method==='POST'&&url==='/api/codeagent/command') {
      try {
        const {prompt,channelId}=JSON.parse(await readBody(req));
        if(!prompt||!channelId) return json({error:'Missing prompt or channelId'},400);
        const ch=client.channels.cache.get(channelId);
        if(!ch) return json({error:'Channel not found'},404);
        ch.send(`\`\`\`\n🤖 Code Agent generating: ${prompt.slice(0,60)}…\n\`\`\``).catch(()=>{});
        return json({success:true});
      } catch(e){return json({error:e.message},500);}
    }

    // Image gen
    if(method==='POST'&&url==='/api/imggen') {
      try {
        const b=JSON.parse(await readBody(req));
        const r=await fetch('https://ai.api.nvidia.com/v1/genai/stabilityai/stable-diffusion-3-medium',{method:'POST',headers:{Authorization:`Bearer ${process.env.NVIDIA_NIM_API_KEY}`,Accept:'application/json','Content-Type':'application/json'},body:JSON.stringify({prompt:b.prompt,cfg_scale:b.cfg_scale||5,aspect_ratio:b.aspect_ratio||'16:9',seed:0,steps:b.steps||40,negative_prompt:b.negative_prompt||''})});
        if(!r.ok){const t=await r.text();return json({error:`API ${r.status}: ${t}`},500);}
        const d=await r.json();
        return json({image:d.image});
      } catch(e){return json({error:e.message},500);}
    }

    // RPC
    if(method==='POST'&&url==='/rpc') {
      const form=parseForm(await readBody(req)); const cfg=loadRpcConfig();
      Object.assign(cfg,{enabled:form.enabled==='1',type:form.type||'PLAYING',name:form.name?.trim()||null,details:form.details?.trim()||null,state:form.state?.trim()||null,imageText:form.imageText?.trim()||null,smallImageText:form.smallImageText?.trim()||null,button1Label:form.button1Label?.trim()||null,button1Url:form.button1Url?.trim()||null,button2Label:form.button2Label?.trim()||null,button2Url:form.button2Url?.trim()||null,imageUrl:isCdn(form.imageUrl?.trim())?form.imageUrl.trim():null,smallImageUrl:isCdn(form.smallImageUrl?.trim())?form.smallImageUrl.trim():null});
      saveRpcConfig(cfg); try{await setRichPresence(client,cfg);}catch{} return redir('/rpc?saved=1');
    }
    if(method==='GET'&&url==='/rpc/clear'){const cfg=loadRpcConfig();cfg.enabled=false;saveRpcConfig(cfg);try{await setRichPresence(client,cfg);}catch{}return redir('/rpc');}

    // AI config
    if(method==='POST'&&url==='/ai'){const form=parseForm(await readBody(req));if(form.personality!==undefined)fs.writeFileSync(path.join(DB_ROOT,'personality.txt'),form.personality);return redir('/ai?saved=1');}

    // AFK
    if(method==='POST'&&url==='/afk/save'){const form=parseForm(await readBody(req));saveAfk({isOn:form.isOn==='1',reason:form.reason?.trim()||'I am currently AFK.',logsEnabled:form.logsEnabled==='1'});return redir('/afk?saved=1');}
    if(method==='GET'&&url==='/afk/deletelog'){saveAfkLogs(loadAfkLogs().filter(l=>l.id!==qs.id));return redir('/afk');}
    if(method==='GET'&&url==='/afk/clearlogs'){saveAfkLogs([]);return redir('/afk');}

    // Reaction
    if(method==='POST'&&url==='/reaction/save'){const form=parseForm(await readBody(req));const rxn=loadReactionData();rxn.global=form.global==='1';saveReactionData(rxn);return redir('/reaction?saved=1');}
    if(method==='POST'&&url==='/reaction/addtrigger'){const form=parseForm(await readBody(req));const rxn=loadReactionData();const emojis=(form.emojis||'').split(/\s+/).filter(Boolean);if(form.type==='text'){if(!rxn.textTriggers)rxn.textTriggers={};rxn.textTriggers[form.trigger]=emojis;}else{if(!rxn.userTriggers)rxn.userTriggers={};rxn.userTriggers[form.trigger]=emojis;}saveReactionData(rxn);return redir('/reaction?saved=1');}
    if(method==='GET'&&url==='/reaction/delete'){const rxn=loadReactionData();if(qs.type==='text')delete rxn.textTriggers[qs.key];else delete rxn.userTriggers[qs.key];saveReactionData(rxn);return redir('/reaction');}

    // Settings
    if(method==='POST'&&url==='/settings/adduser'){const form=parseForm(await readBody(req));const uid=form.userId?.trim();if(uid&&/^\d{17,20}$/.test(uid)){const d=rj('allowedUsers.json',{allowedUsers:[]});if(!d.allowedUsers.includes(uid)){d.allowedUsers.push(uid);wj('allowedUsers.json',d);}return redir('/settings?saved=1');}return redir('/settings?err=invalid');}
    if(method==='GET'&&url==='/settings/removeuser'){const d=rj('allowedUsers.json',{allowedUsers:[]});d.allowedUsers=d.allowedUsers.filter(u=>u!==qs.id);wj('allowedUsers.json',d);return redir('/settings');}

    // Guilds - leave
    if(method==='POST'&&url==='/api/guilds/leave'){const{guildId}=JSON.parse(await readBody(req));try{const g=client.guilds.cache.get(guildId);if(g){await g.leave();}return json({success:true});}catch(e){return json({success:false,message:e.message});}}

    // API: validate
    if(method==='POST'&&url==='/api/validate/guild'){const b=JSON.parse(await readBody(req));const g=client.guilds.cache.get(b.id);if(!g)return json({error:'Not found'},404);return json({id:g.id,name:g.name,icon:g.iconURL({dynamic:true})||''});}
    if(method==='POST'&&url==='/api/validate/channel'){const b=JSON.parse(await readBody(req));const c=client.channels.cache.get(b.id);if(!c)return json({error:'Not found'},404);return json({id:c.id,name:c.name,guildName:c.guild?.name||'DM',guildIcon:c.guild?.iconURL({dynamic:true})||''});}
    if(method==='POST'&&url==='/api/validate/user'){const b=JSON.parse(await readBody(req));try{const u=await client.users.fetch(b.id);return json({id:u.id,username:u.username,avatar:u.displayAvatarURL({dynamic:true})});}catch{return json({error:'Not found'},404);}}

    // API: Logs
    if(method==='GET'&&url==='/api/logs') return json(loadAfkLogs());

    // API: Music
    if(method==='GET'&&url==='/api/music/status') return json(getMusicStatus(client,lavalink,queueManager,voiceStates));
    if(method==='POST'&&url==='/api/music/join'){const b=JSON.parse(await readBody(req));client.ws.broadcast({op:4,d:{guild_id:b.guildId,channel_id:b.channelId,self_mute:false,self_deaf:false}});return json({success:true});}
    if(method==='POST'&&url==='/api/music/leave'){const b=JSON.parse(await readBody(req));queueManager.delete(b.guildId);if(lavalink)await lavalink.destroyPlayer(b.guildId).catch(()=>{});if(voiceStates[b.guildId])delete voiceStates[b.guildId];client.ws.broadcast({op:4,d:{guild_id:b.guildId,channel_id:null,self_mute:false,self_deaf:false}});return json({success:true});}
    if(method==='POST'&&url==='/api/music/stop'){let stopped=false;for(const[gId,q]of queueManager.getAll()){if(q.nowPlaying){if(lavalink)await lavalink.destroyPlayer(gId).catch(()=>{});queueManager.delete(gId);stopped=true;}}return json({success:stopped});}
    if(method==='POST'&&url==='/api/music/skip'){for(const[gId,q]of queueManager.getAll()){if(!q.nowPlaying)continue;const next=queueManager.getNext(gId);if(!next){if(lavalink)await lavalink.destroyPlayer(gId).catch(()=>{});queueManager.delete(gId);}else{if(q.history)q.history.push(q.nowPlaying);q.nowPlaying=next;q.position=0;q.lastUpdate=Date.now();const vs=voiceStates[gId];if(vs&&lavalink)await lavalink.updatePlayer(gId,next,vs).catch(()=>{});}return json({success:true});}return json({success:false});}
    if(method==='POST'&&url==='/api/music/previous'){for(const[gId,q]of queueManager.getAll()){if(!q.nowPlaying||!q.history?.length)continue;const prev=q.history.pop();q.songs.unshift(q.nowPlaying);q.nowPlaying=prev;q.position=0;q.lastUpdate=Date.now();const vs=voiceStates[gId];if(vs&&lavalink)await lavalink.updatePlayer(gId,prev,vs).catch(()=>{});return json({success:true});}return json({success:false});}
    if(method==='POST'&&url==='/api/music/play'){
      const b=JSON.parse(await readBody(req));
      if(!b.guildId||!b.query)return json({success:false,message:'Missing args'});
      if(!lavalink)return json({success:false,message:'Lavalink not connected'});
      try{
        const id=/^(https?:\/\/|www\.)/i.test(b.query)?b.query:`ytmsearch:${b.query}`;
        const result=await lavalink.loadTracks(id);
        if(result.loadType==='empty')return json({success:false,message:'No results'});
        let track;
        if(result.loadType==='track')track=result.data;
        else if(result.loadType==='search')track=result.data[0];
        else if(result.loadType==='playlist')track=result.data.tracks[0];
        if(!track)return json({success:false,message:'No track'});
        let q=queueManager.get(b.guildId)||queueManager.create(b.guildId);
        if(q.nowPlaying){queueManager.addSong(b.guildId,track);return json({success:true,queued:true});}
        const vs=voiceStates[b.guildId];
        if(!vs?.channelId)return json({success:false,message:'Not in voice channel'});
        q.nowPlaying=track;q.position=0;q.lastUpdate=Date.now();
        await lavalink.updatePlayer(b.guildId,track,vs,{volume:q.volume,filters:q.filters});
        return json({success:true,queued:false});
      }catch(e){return json({success:false,message:e.message});}
    }
    if(method==='GET'&&url==='/api/discord/guilds')return json([...client.guilds.cache.values()].map(g=>({id:g.id,name:g.name,icon:g.icon||null,acronym:g.name.split(' ').map(w=>w[0]||'').join('').slice(0,2).toUpperCase()||g.name.charAt(0).toUpperCase()})));
    if(method==='GET'&&url.startsWith('/api/discord/voice/')){const g=client.guilds.cache.get(url.split('/').pop());if(!g)return json([]);return json([...g.channels.cache.values()].filter(c=>c.type==='GUILD_VOICE'||c.type===2||c.type==='GUILD_STAGE_VOICE'||c.type===13).map(c=>({id:c.id,name:c.name})));}

    // API: Reaction
    if(method==='GET'&&url==='/api/reaction'){const d=loadReactionData();const es=(d.enabledServers||[]).map(id=>{const g=client.guilds.cache.get(id);return{id,name:g?.name||'Unknown',icon:g?.iconURL({dynamic:true})||''};});const ec=(d.enabledChannels||[]).map(id=>{const c=client.channels.cache.get(id);return{id,name:c?.name||'Unknown',guildName:c?.guild?.name||'',guildIcon:c?.guild?.iconURL({dynamic:true})||''};});return json({...d,enrichedServers:es,enrichedChannels:ec});}
    if(method==='POST'&&url==='/api/reaction'){saveReactionData(JSON.parse(await readBody(req)));return json({success:true});}

    // API: Cloner
    if(method==='GET'&&url==='/api/cloner/status')return json({isRunning:clonerState.isRunning,logs:clonerState.logs,stats:clonerState.stats});
    if(method==='POST'&&url==='/api/cloner/fetch'){const b=JSON.parse(await readBody(req));const g=client.guilds.cache.get(b.guildId);if(!g)return json({success:false,message:'Guild not found — bot must be a member'});const mem=await g.members.fetch(client.user.id).catch(()=>null);const isAdmin=mem?.permissions.has('ADMINISTRATOR')??false;return json({success:true,name:g.name,icon:g.iconURL({dynamic:true,size:128})||'',isAdmin,isOwner:g.ownerId===client.user.id});}
    if(method==='POST'&&url==='/api/cloner/start'){
      if(clonerState.isRunning)return json({success:false,message:'Already running'});
      const{sourceId,targetId,options}=JSON.parse(await readBody(req));
      clonerState.isRunning=true;clonerState.logs=[];clonerState.stats={};
      clonerState.logs.push(`[${new Date().toLocaleTimeString()}] Initializing…`);
      const SC=__require('../cloner/ServerCloner.cjs');
      const cloner=new SC(client,msg=>{clonerState.logs.push(`[${new Date().toLocaleTimeString()}] ${msg}`);if(clonerState.logs.length>500)clonerState.logs.shift();});
      cloner.cloneServer(sourceId,targetId,options).then(s=>{clonerState.stats=s;clonerState.isRunning=false;clonerState.logs.push(`[${new Date().toLocaleTimeString()}] ✓ Completed`);}).catch(e=>{clonerState.isRunning=false;clonerState.logs.push(`[${new Date().toLocaleTimeString()}] ✕ Error: ${e.message}`);});
      return json({success:true});
    }

    // API: Quests
    if(method==='GET'&&url==='/api/quests')return json(client._questManager?{logs:client._questManager.globalLogs,isRunning:client._questManager.isRunning}:{logs:[],isRunning:false});
    if(method==='POST'&&url==='/quest/start-all'){client._questManager?.startAll();return json({success:true});}
    if(method==='POST'&&url==='/quest/stop-all'){client._questManager?.stopAll();return json({success:true});}
    if(method==='POST'&&url==='/quest/clear-logs'){client._questManager?.clearLogs();return json({success:true});}

    // ── API: Discord /me ──
    // ══ DISCORD CHAT APIs ════════════════════════════════════════════════════

    // /api/me — selfbot user info
    if(method==='GET'&&url==='/api/me'){
      const u=client.user;
      return json({id:u?.id||'',username:u?.username||'',discriminator:u?.discriminator||'0',avatar:u?.avatar||null,avatarUrl:u?.displayAvatarURL({dynamic:true,size:128})||''});
    }

    // /api/discord/dms — list DM channels
    if(method==='GET'&&url==='/api/discord/dms'){
      const dms=[...client.channels.cache.values()]
        .filter(c=>c.type==='DM'||c.type===1)
        .map(c=>({
          id:c.id,
          recipientId:c.recipient?.id||'',
          recipientName:c.recipient?.username||'DM',
          recipientAvatar:c.recipient?.avatar||null,
          recipientAvatarUrl:c.recipient?.displayAvatarURL({dynamic:true,size:64})||'',
          lastMessageId:c.lastMessageId||null,
        }))
        .slice(0,100);
      return json(dms);
    }

    // /api/discord/guilds — all servers with unreads stub
    if(method==='GET'&&url==='/api/discord/guilds'){
      return json([...client.guilds.cache.values()].map(g=>({
        id:g.id, name:g.name, icon:g.icon||null,
        acronym:g.name.split(' ').map(w=>w[0]||'').join('').slice(0,2).toUpperCase()||g.name.charAt(0).toUpperCase(),
        memberCount:g.memberCount||0,
        ownerId:g.ownerId
      })));
    }

    // /api/discord/channels/all/:guildId — channels + members + categories
    if(method==='GET'&&url.startsWith('/api/discord/channels/all/')){
      const guildId=url.replace('/api/discord/channels/all/','').split('?')[0];
      const g=client.guilds.cache.get(guildId);
      if(!g) return json({channels:[],members:[],categories:[]});
      const allCh=[...g.channels.cache.values()].sort((a,b)=>a.position-b.position);
      const categories=allCh.filter(c=>c.type===4||c.type==='GUILD_CATEGORY').map(c=>({id:c.id,name:c.name,position:c.position}));
      const channels=allCh
        .filter(c=>c.type===0||c.type===5||c.type==='GUILD_TEXT'||c.type==='GUILD_NEWS')
        .map(c=>({id:c.id,name:c.name,type:String(c.type),topic:c.topic||'',position:c.position,parentId:c.parentId||null,parentName:c.parent?.name||null,nsfw:c.nsfw||false}));
      const voiceChs=allCh
        .filter(c=>c.type===2||c.type===13||c.type==='GUILD_VOICE'||c.type==='GUILD_STAGE_VOICE')
        .map(c=>({id:c.id,name:c.name,type:String(c.type),parentId:c.parentId||null,parentName:c.parent?.name||null}));
      const members=[...g.members.cache.values()].slice(0,150).map(m=>({
        id:m.id,username:m.user.username,displayName:m.displayName,
        avatarUrl:m.user.displayAvatarURL({dynamic:true,size:64}),
        status:m.presence?.status||'offline',
        activity:m.presence?.activities?.[0]?.name||null,
        isBot:m.user.bot||false,
        color:m.displayHexColor&&m.displayHexColor!=='#000000'?m.displayHexColor:null,
      }));
      return json({channels,voiceChannels:voiceChs,categories,members});
    }

    // /api/discord/messages/:channelId — fetch messages
    if(method==='GET'&&url.startsWith('/api/discord/messages/')){
      const channelId=url.replace('/api/discord/messages/','').split('?')[0];
      const limit=Math.min(parseInt(qs.limit||'50'),100);
      const ch=client.channels.cache.get(channelId);
      if(!ch) return json([]);
      try{
        const opts={limit};
        if(qs.before) opts.before=qs.before;
        if(qs.after&&qs.after!=='0') opts.after=qs.after;
        const msgs=await ch.messages.fetch(opts);
        const arr=[...msgs.values()].reverse().map(m=>({
          id:m.id,
          author:m.author.username,authorId:m.author.id,
          displayName:m.member?.displayName||m.author.username,
          avatarUrl:m.author.displayAvatarURL({dynamic:true,size:64}),
          color:m.member?.displayHexColor&&m.member.displayHexColor!=='#000000'?m.member.displayHexColor:null,
          content:m.content||'',
          timestamp:m.createdTimestamp,
          editedAt:m.editedTimestamp||null,
          attachments:[...m.attachments.values()].map(a=>({url:a.url,name:a.name,size:a.size,type:a.contentType||''})),
          embeds:m.embeds.map(e=>({title:e.title,description:e.description,url:e.url,color:e.color,image:e.image?.url||null,thumbnail:e.thumbnail?.url||null,fields:e.fields})),
          reactions:[...m.reactions.cache.values()].map(r=>({emoji:r.emoji.toString(),count:r.count,me:r.me})),
          isBot:m.author.bot,
          isPinned:m.pinned||false,
          replyTo:m.reference?.messageId||null,
          replyAuthor:m.mentions?.repliedUser?.username||null,
          replyContent:null,
          stickers:[...m.stickers?.values()||[]].map(s=>({id:s.id,name:s.name,url:`https://media.discordapp.net/stickers/${s.id}.webp?size=160`})),
          type:m.type,
        }));
        return json(arr);
      }catch(e){console.error('[DC msgs]',e.message);return json([]);}
    }

    // /api/discord/send — send message
    if(method==='POST'&&url==='/api/discord/send'){
      const b=JSON.parse(await readBody(req));
      const ch=client.channels.cache.get(b.channelId);
      if(!ch) return json({success:false,message:'Channel not found'});
      try{
        const opts={content:b.content};
        if(b.replyTo) opts.reply={messageReference:b.replyTo,failIfNotExists:false};
        await ch.send(opts);
        return json({success:true});
      }catch(e){return json({success:false,message:e.message});}
    }

    // /api/discord/edit — edit a message
    if(method==='POST'&&url==='/api/discord/edit'){
      const b=JSON.parse(await readBody(req));
      const ch=client.channels.cache.get(b.channelId);
      if(!ch) return json({success:false,message:'Channel not found'});
      try{
        const msg=await ch.messages.fetch(b.messageId);
        await msg.edit(b.content);
        return json({success:true});
      }catch(e){return json({success:false,message:e.message});}
    }

    // /api/discord/delete — delete a message
    if(method==='POST'&&url==='/api/discord/delete'){
      const b=JSON.parse(await readBody(req));
      const ch=client.channels.cache.get(b.channelId);
      if(!ch) return json({success:false,message:'Channel not found'});
      try{
        const msg=await ch.messages.fetch(b.messageId);
        await msg.delete();
        return json({success:true});
      }catch(e){return json({success:false,message:e.message});}
    }

    // /api/discord/react — add reaction
    if(method==='POST'&&url==='/api/discord/react'){
      const b=JSON.parse(await readBody(req));
      const ch=client.channels.cache.get(b.channelId);
      if(!ch) return json({success:false,message:'Channel not found'});
      try{
        const msg=await ch.messages.fetch(b.messageId);
        await msg.react(b.emoji);
        return json({success:true});
      }catch(e){return json({success:false,message:e.message});}
    }

    // /api/discord/typing — send typing indicator
    if(method==='POST'&&url==='/api/discord/typing'){
      const b=JSON.parse(await readBody(req));
      const ch=client.channels.cache.get(b.channelId);
      if(ch) await ch.sendTyping().catch(()=>{});
      return json({success:true});
    }

    // /api/discord/pins/:channelId — get pinned messages
    if(method==='GET'&&url.startsWith('/api/discord/pins/')){
      const channelId=url.replace('/api/discord/pins/','').split('?')[0];
      const ch=client.channels.cache.get(channelId);
      if(!ch) return json([]);
      try{
        const pins=await ch.messages.fetchPinned();
        return json([...pins.values()].map(m=>({id:m.id,author:m.author.username,avatarUrl:m.author.displayAvatarURL({dynamic:true,size:64}),content:m.content,timestamp:m.createdTimestamp})));
      }catch(e){return json([]);}
    }

    // /api/discord/search — search messages in a guild
    if(method==='GET'&&url==='/api/discord/search'){
      const gid=qs.guildId, q2=qs.q, cid=qs.channelId;
      if(!gid||!q2) return json([]);
      try{
        const g=client.guilds.cache.get(gid);
        if(!g) return json([]);
        // Search via REST
        let searchUrl=`https://discord.com/api/v9/guilds/${gid}/messages/search?content=${encodeURIComponent(q2)}&limit=25`;
        if(cid) searchUrl+=`&channel_id=${cid}`;
        const r=await fetch(searchUrl,{headers:{Authorization:client.token}});
        const data=await r.json();
        const results=(data.messages||[]).flat().map(m=>({id:m.id,author:m.author.username,avatarUrl:`https://cdn.discordapp.com/avatars/${m.author.id}/${m.author.avatar}.webp?size=64`,content:m.content,timestamp:new Date(m.timestamp).getTime(),channelId:m.channel_id}));
        return json(results);
      }catch(e){return json([]);}
    }

        // ── Page routes — serve HTML views ────────────────────────────────────────
    const flash = qs.saved?'Saved successfully ✓':(qs.err?'Error: '+qs.err:'');

    if(url==='/')        return html(layout('home','Overview',user,view('home.html').replace('{{STATS}}',buildStats(client,lavalink,queueManager,voiceStates))));
    if(url==='/account') return html(layout('account','Account',user,buildAccount(client)));
    if(url==='/guilds')  return html(layout('guilds','Servers',user,buildGuilds(client)));
    if(url==='/rpc')     return html(layout('rpc','Rich Presence',user,buildRPC(loadRpcConfig()),flash));
    if(url==='/ai')      return html(layout('ai','AI Config',user,buildAI(),flash));
    if(url==='/aichat')  return html(layout('aichat','AI Chat',user,view('aichat.html')));
    if(url==='/codeagent') return html(layout('codeagent','Code Agent',user,view('codeagent.html')));
    if(url==='/afk')     return html(layout('afk','AFK System',user,buildAFK(loadAfk(),loadAfkLogs()),flash));
    if(url==='/reaction') return html(layout('reaction','Auto Reaction',user,buildReaction(loadReactionData()),flash));
    if(url==='/music')   return html(layout('music','Music Player',user,view('music.html')));
    if(url==='/cloner')  return html(layout('cloner','Server Cloner',user,view('cloner.html')));
    if(url==='/quests')  return html(layout('quests','Quest Terminal',user,view('quests.html')));
    if(url==='/imggen')  return html(layout('imggen','Image Generator',user,view('imggen.html').replace('{{NIM_WARN}}',!process.env.NVIDIA_NIM_API_KEY?'<div class="flash flash-err">⚠ NVIDIA_NIM_API_KEY not set in .env</div>':'')));
    if(url==='/discordchat') return html(layout('discordchat','Server Chat',user,view('discordchat.html')));
        if(url==='/commands') return html(layout('commands','Commands',user,buildCommands(client)));
    if(url==='/logs')    return html(layout('logs','Activity Logs',user,buildLogs(client)));
    if(url==='/settings') return html(layout('settings','Settings',user,buildSettings(client),flash));
    redir('/');
  }).listen(PORT,()=>console.log(`[Dashboard] http://localhost:${PORT}`));
}

// ── Server-side page data builders ───────────────────────────────────────────
function buildStats(client,lavalink,queueManager,voiceStates) {
  const rpc=loadRpcConfig(),afk=loadAfk();
  let aiEnabled=0; try{aiEnabled=Object.values(rj('ai_config.json')).filter(c=>c.enabled).length;}catch{}
  const music=getMusicStatus(client,lavalink,queueManager,voiceStates);
  const upSec=Math.floor(process.uptime()),h=Math.floor(upSec/3600),m=Math.floor((upSec%3600)/60),s=upSec%60;
  const stats=[
    {ic:'👤',v:esc(client.user?.username||'—'),l:'Account',c:'#8b5cf6'},
    {ic:'🌐',v:client.guilds?.cache?.size??0,l:'Servers',c:'#3b82f6'},
    {ic:'⚡',v:client.commands?.size??0,l:'Commands',c:'#22c55e'},
    {ic:'⏱️',v:`${h}h${String(m).padStart(2,'0')}m${String(s).padStart(2,'0')}s`,l:'Uptime',c:'#f59e0b'},
    {ic:'🤖',v:aiEnabled,l:'AI Guilds',c:'#06b6d4'},
    {ic:'🎵',v:music.isPlaying?'Playing':music.isConnectedToVoice?'Connected':'Idle',l:'Music',c:music.isPlaying?'#22c55e':'#52527a'},
  ];
  return stats.map(s=>`<div class="stat-card" style="--sc:${s.c}"><div class="stat-ic">${s.ic}</div><div class="stat-v">${s.v}</div><div class="stat-l">${s.l}</div></div>`).join('');
}

function buildAccount(client) {
  const u=client.user;
  const keys={groq:!!process.env.GROQ_API_KEY,openrouter:!!process.env.OPENROUTER_API_KEY,nim:!!process.env.NVIDIA_NIM_API_KEY};
  return `
<div class="ph"><h1 class="pt">Account</h1><p class="ps">Your Discord account information</p></div>
<div class="account-hero">
  <div class="account-avatar-placeholder">${esc(u?.username?.charAt(0)?.toUpperCase()||'?')}</div>
  <div>
    <div class="account-name">${esc(u?.username||'—')}</div>
    <div class="account-tag">ID: ${esc(u?.id||'—')}</div>
    <div class="account-badges" style="margin-top:8px">
      <span class="badge badge-green">● Online</span>
      ${u?.bot?'<span class="badge badge-blue">Bot</span>':'<span class="badge badge-purple">Selfbot</span>'}
    </div>
  </div>
</div>
<div class="two-col">
  <div class="card">
    <div class="card-h"><div class="card-hl"><span class="card-ic">👤</span><span class="card-t">Account Details</span></div></div>
    <div class="card-b">
      <div class="info-list">
        <div class="ir"><span class="ik">Username</span><span class="iv">${esc(u?.username||'—')}</span></div>
        <div class="ir"><span class="ik">User ID</span><code>${esc(u?.id||'—')}</code></div>
        <div class="ir"><span class="ik">Discriminator</span><span class="iv">#${esc(u?.discriminator||'0')}</span></div>
        <div class="ir"><span class="ik">Account Type</span><span class="badge badge-purple">Selfbot</span></div>
        <div class="ir"><span class="ik">Prefix</span><code>${esc(process.env.PREFIX||'!')}</code></div>
        <div class="ir"><span class="ik">Owner ID</span><code>${esc(process.env.OWNER_ID||'Not set')}</code></div>
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-h"><div class="card-hl"><span class="card-ic">🔧</span><span class="card-t">Bot Status</span></div></div>
    <div class="card-b">
      <div class="info-list">
        <div class="ir"><span class="ik">Discord</span><span class="badge badge-green">● Connected</span></div>
        <div class="ir"><span class="ik">Node.js</span><span class="iv">${process.version}</span></div>
        <div class="ir"><span class="ik">Memory</span><span class="iv">${Math.round(process.memoryUsage().heapUsed/1024/1024)}MB</span></div>
        <div class="ir"><span class="ik">Uptime</span><span class="iv" id="uptimeLive">—</span></div>
        <div class="ir"><span class="ik">Platform</span><span class="iv">${process.platform}</span></div>
        <div class="ir"><span class="ik">Dashboard Port</span><code>${process.env.DASH_PORT||3000}</code></div>
      </div>
    </div>
  </div>
</div>
<div class="card">
  <div class="card-h"><div class="card-hl"><span class="card-ic">🔑</span><span class="card-t">API Keys Status</span></div></div>
  <div class="card-b">
    <div class="grid-3">
      ${[['Groq',keys.groq,'For fast llama models'],['OpenRouter',keys.openrouter,'For GPT-OSS-120b model'],['NVIDIA NIM',keys.nim,'For code agent & images']].map(([n,set,desc])=>`<div class="card" style="margin:0;background:var(--surf2)"><div class="card-b"><div style="font-weight:600;font-size:.82rem;margin-bottom:4px">${n}</div><div style="font-size:.72rem;color:var(--muted);margin-bottom:8px">${desc}</div><span class="badge ${set?'badge-green':'badge-red'}">${set?'● Configured':'Not set'}</span></div></div>`).join('')}
    </div>
  </div>
</div>
<script>
let st=${Math.floor(process.uptime())};
setInterval(()=>{st++;const h=Math.floor(st/3600),m=Math.floor((st%3600)/60),s=st%60;document.getElementById('uptimeLive').textContent=h+'h '+String(m).padStart(2,'0')+'m '+String(s).padStart(2,'0')+'s';},1000);
</script>`;
}

function buildGuilds(client) {
  const guilds=[...client.guilds.cache.values()].sort((a,b)=>b.memberCount-a.memberCount);
  const cards=guilds.map(g=>{
    const icon=g.iconURL({dynamic:true,size:64});
    const initials=g.name.split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase();
    return `<div class="guild-card">
      <div class="guild-icon">${icon?`<img src="${esc(icon)}" alt="">`:`<span>${esc(initials)}</span>`}</div>
      <div class="guild-info">
        <div class="guild-name">${esc(g.name)}</div>
        <div class="guild-meta">${g.memberCount?.toLocaleString()||'?'} members · ID: ${g.id}</div>
        <div style="margin-top:4px">
          ${g.ownerId===client.user?.id?'<span class="badge badge-yellow">Owner</span>':''}
          ${g.members?.me?.permissions?.has('ADMINISTRATOR')?'<span class="badge badge-blue">Admin</span>':''}
        </div>
      </div>
      ${g.ownerId!==client.user?.id?`<button class="btn btn-danger btn-xs" onclick="leaveGuild('${g.id}','${esc(g.name)}')">Leave</button>`:'<span class="badge badge-yellow">Owner</span>'}
    </div>`;
  }).join('');
  return `
<div class="ph"><h1 class="pt">Servers <span style="font-size:.9rem;font-weight:400;color:var(--muted)">(${guilds.length})</span></h1><p class="ps">All servers your selfbot is in</p></div>
<div class="guild-grid" id="guildGrid">${cards||'<div class="empty-state"><div class="es-icon">🌐</div><div class="es-title">No servers</div></div>'}</div>
<div class="modal-bg" id="leaveModal">
  <div class="modal-box">
    <div class="modal-title">Leave Server</div>
    <p style="font-size:.84rem;color:var(--text2);margin-bottom:16px">Are you sure you want to leave <strong id="leaveGuildName"></strong>?</p>
    <div style="display:flex;gap:10px">
      <button class="btn btn-danger" id="leaveConfirm">Leave</button>
      <button class="btn btn-ghost" onclick="document.getElementById('leaveModal').classList.remove('show')">Cancel</button>
    </div>
  </div>
</div>
<script>
let _leaveId='';
function leaveGuild(id,name){_leaveId=id;document.getElementById('leaveGuildName').textContent=name;document.getElementById('leaveModal').classList.add('show');}
document.getElementById('leaveConfirm').onclick=async()=>{
  const r=await fetch('/api/guilds/leave',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({guildId:_leaveId})});
  const d=await r.json();
  document.getElementById('leaveModal').classList.remove('show');
  if(d.success)location.reload();else alert('Failed: '+(d.message||'Unknown error'));
};
</script>`;
}

function buildRPC(cfg) {
  const types=['PLAYING','STREAMING','LISTENING','WATCHING','COMPETING'];
  const opts=types.map(t=>`<option value="${t}"${cfg.type===t?' selected':''}>${t}</option>`).join('');
  const prev=cfg.imageUrl?`<img src="${esc(cfg.imageUrl)}" alt="" onerror="this.style.display='none'" style="width:100%;height:100%;object-fit:cover;border-radius:8px">`:'🎮';
  return view('rpc.html')
    .replace('{{STATUS_BADGE}}',cfg.enabled?'<span class="badge badge-green">● Active</span>':'<span class="badge badge-gray">Disabled</span>')
    .replace('{{RPC_PREVIEW_IMG}}',prev)
    .replace('{{RPC_PREV_TYPE}}',esc(cfg.type||'PLAYING'))
    .replace('{{RPC_PREV_NAME}}',esc(cfg.name||'Activity Name'))
    .replace('{{RPC_PREV_DET}}',cfg.details?`<div class="rpc-det" id="pvDet">${esc(cfg.details)}</div>`:'<div class="rpc-det" id="pvDet" style="display:none"></div>')
    .replace('{{RPC_PREV_STATE}}',cfg.state?`<div class="rpc-det" id="pvState">${esc(cfg.state)}</div>`:'<div class="rpc-det" id="pvState" style="display:none"></div>')
    .replace('{{RPC_PREV_BTNS}}',[cfg.button1Label,cfg.button2Label].filter(Boolean).map(l=>`<span class="rpc-btn-p">${esc(l)}</span>`).join(''))
    .replace('{{F_ENABLED}}',cfg.enabled?'checked':'')
    .replace('{{F_TYPE_OPTS}}',opts)
    .replace('{{F_NAME}}',esc(cfg.name||''))
    .replace('{{F_DETAILS}}',esc(cfg.details||''))
    .replace('{{F_STATE}}',esc(cfg.state||''))
    .replace('{{F_IMG}}',esc(cfg.imageUrl||''))
    .replace('{{F_IMG_TXT}}',esc(cfg.imageText||''))
    .replace('{{F_SIMG}}',esc(cfg.smallImageUrl||''))
    .replace('{{F_SIMG_TXT}}',esc(cfg.smallImageText||''))
    .replace('{{F_B1L}}',esc(cfg.button1Label||''))
    .replace('{{F_B1U}}',esc(cfg.button1Url||''))
    .replace('{{F_B2L}}',esc(cfg.button2Label||''))
    .replace('{{F_B2U}}',esc(cfg.button2Url||''));
}

function buildAI() {
  let aiCfg={}; try{aiCfg=rj('ai_config.json');}catch{}
  let personality=''; try{personality=fs.readFileSync(path.join(DB_ROOT,'personality.txt'),'utf8');}catch{}
  const PROV={groq:'Groq',openrouter:'OpenRouter',nim:'NVIDIA NIM'};
  const keys={groq:!!process.env.GROQ_API_KEY,openrouter:!!process.env.OPENROUTER_API_KEY,nim:!!process.env.NVIDIA_NIM_API_KEY};
  const entries=Object.entries(aiCfg);
  const tbody=entries.map(([gId,cfg])=>`<tr><td><code>${esc(gId)}</code></td><td><span class="badge ${cfg.enabled?'badge-green':'badge-red'}">${cfg.enabled?'On':'Off'}</span></td><td>${esc(PROV[cfg.provider]||cfg.provider||'Groq')}</td><td>${cfg.channels?.length??0}</td><td><span class="badge badge-blue">${cfg.respondToAll?'Everyone':'Owner'}</span></td></tr>`).join('')||`<tr><td colspan="5" style="text-align:center;color:var(--muted);padding:20px">No guilds — use <code>ai on</code> in Discord</td></tr>`;
  return view('ai.html')
    .replace('{{KEY_GROQ}}',keys.groq?'badge-green':'badge-gray').replace('{{KEY_GROQ_TXT}}',keys.groq?'● Set':'Missing')
    .replace('{{KEY_OR}}',keys.openrouter?'badge-green':'badge-gray').replace('{{KEY_OR_TXT}}',keys.openrouter?'● Set':'Missing')
    .replace('{{KEY_NIM}}',keys.nim?'badge-green':'badge-gray').replace('{{KEY_NIM_TXT}}',keys.nim?'● Set':'Missing')
    .replace('{{AI_TOTAL}}',entries.length)
    .replace('{{AI_ENABLED}}',entries.filter(([,c])=>c.enabled).length)
    .replace('{{AI_PROVS}}',[...new Set(entries.map(([,c])=>PROV[c.provider]||'Groq'))].join(', ')||'—')
    .replace('{{PERSONALITY}}',esc(personality))
    .replace('{{GUILD_ROWS}}',tbody);
}

function buildAFK(afk,logs) {
  const logHtml=logs.length?logs.map(l=>`<div class="log-entry"><div class="le-info"><span class="le-user">${esc(l.user)}</span><span class="le-msg">"${esc(l.content)}"</span><span class="le-meta">${esc(l.time)} · ${esc(l.guild)} #${esc(l.channel)} <a href="${esc(l.link)}" target="_blank" class="le-link">↗</a></span></div><a href="/afk/deletelog?id=${esc(l.id)}" class="btn btn-danger btn-xs">✕</a></div>`).join(''):'<div style="text-align:center;color:var(--muted);padding:20px">No mentions yet</div>';
  return view('afk.html')
    .replace('{{AFK_BADGE}}',afk.isOn?'<span class="badge badge-green">● Active</span>':'<span class="badge badge-gray">Off</span>')
    .replace('{{AFK_ON}}',afk.isOn?'checked':'')
    .replace('{{AFK_LOGS}}',afk.logsEnabled?'checked':'')
    .replace('{{AFK_REASON}}',esc(afk.reason||'I am currently AFK.'))
    .replace('{{LOG_ENTRIES}}',logHtml);
}

function buildReaction(rxn) {
  const mkT=(obj,type)=>{const e=Object.entries(obj||{});return e.length?e.map(([t,em])=>`<div class="trig-row"><div><div class="trig-k">"${esc(t)}"</div><div class="trig-em">${esc(em.join(' '))}</div></div><a href="/reaction/delete?type=${type}&key=${encodeURIComponent(t)}" class="btn btn-danger btn-xs">Remove</a></div>`).join(''):`<div style="text-align:center;color:var(--muted);padding:14px">No ${type} triggers</div>`;};
  return view('reaction.html')
    .replace('{{GLOBAL_CHK}}',rxn.global?'checked':'')
    .replace('{{TEXT_TRIGGERS}}',mkT(rxn.textTriggers,'text'))
    .replace('{{USER_TRIGGERS}}',mkT(rxn.userTriggers,'user'));
}

function buildCommands(client) {
  const cats={};
  for(const[,cmd]of(client.commands??new Map())){const cat=cmd.category||'misc';if(!cats[cat])cats[cat]=[];cats[cat].push(cmd);}
  const icons={music:'🎵',ai:'🤖',fun:'🎉',fun2:'🎪',moderation:'🔨',tools:'🔧',utility:'⚙️',misc:'📦'};
  const html=Object.entries(cats).map(([cat,cmds])=>`
<div class="card"><div class="card-h"><div class="card-hl"><span class="card-ic">${icons[cat]||'📦'}</span><span class="card-t">${cat.charAt(0).toUpperCase()+cat.slice(1)} <small style="font-weight:400;color:var(--muted)">(${cmds.length})</small></span></div></div>
<div class="card-b no-pad"><div class="tbl-wrap"><table><thead><tr><th>Command</th><th>Aliases</th><th>Description</th><th>Usage</th></tr></thead>
<tbody>${cmds.map(c=>`<tr><td><code>${esc(process.env.PREFIX||'!')}${esc(c.name)}</code></td><td style="color:var(--muted)">${esc((c.aliases||[]).join(', '))||'—'}</td><td style="color:var(--text2)">${esc(c.description||'—')}</td><td><code style="font-size:.7rem">${esc(c.usage||c.name)}</code></td></tr>`).join('')}</tbody>
</table></div></div></div>`).join('')||'<div class="empty-state"><div class="es-icon">📭</div><div class="es-title">No commands loaded</div></div>';
  return `<div class="ph"><h1 class="pt">Commands</h1><p class="ps">${client.commands?.size??0} commands across ${Object.keys(cats).length} categories</p></div>${html}`;
}

function buildLogs(client) {
  const afkLogs=loadAfkLogs();
  const msgs=[...(client.deletedMessages?.entries()??[])].slice(0,30).map(([ch,m])=>({ch,...m}));
  const afkHtml=afkLogs.length?afkLogs.map(l=>`<div class="log-entry"><div class="le-info"><span class="le-user">${esc(l.user)}</span><span class="le-msg">"${esc(l.content)}"</span><span class="le-meta">${esc(l.time)} · ${esc(l.guild)} #${esc(l.channel)} <a href="${esc(l.link)}" target="_blank" class="le-link">↗</a></span></div><a href="/afk/deletelog?id=${esc(l.id)}" class="btn btn-danger btn-xs">✕</a></div>`).join(''):'<div style="text-align:center;color:var(--muted);padding:20px">No AFK logs</div>';
  const msgHtml=msgs.length?msgs.map(m=>`<tr><td>${esc(m.author||'?')}</td><td style="max-width:280px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(m.content||'')}</td><td><code>${esc(m.ch)}</code></td><td>${new Date(m.timestamp||0).toLocaleTimeString()}</td></tr>`).join(''):'<tr><td colspan="4" style="text-align:center;color:var(--muted);padding:20px">No sniped messages</td></tr>';
  return `<div class="ph"><h1 class="pt">Activity Logs</h1><p class="ps">AFK mentions and sniped messages</p></div>
<div class="card"><div class="card-h"><div class="card-hl"><span class="card-ic">📬</span><span class="card-t">AFK Mention Logs</span></div><a href="/afk/clearlogs" class="btn btn-danger btn-sm">Clear All</a></div><div class="card-b" id="afkLogsCont">${afkHtml}</div></div>
<div class="card"><div class="card-h"><div class="card-hl"><span class="card-ic">🗑️</span><span class="card-t">Sniped Messages</span></div></div><div class="card-b no-pad"><div class="tbl-wrap"><table><thead><tr><th>Author</th><th>Content</th><th>Channel</th><th>Time</th></tr></thead><tbody>${msgHtml}</tbody></table></div></div>
<script>setInterval(async()=>{const r=await fetch('/api/logs');const logs=await r.json();const c=document.getElementById('afkLogsCont');if(logs.length)c.innerHTML=logs.map(l=>'<div class="log-entry"><div class="le-info"><span class="le-user">'+l.user+'</span><span class="le-msg">"'+l.content+'"</span><span class="le-meta">'+l.time+' · '+l.guild+' #'+l.channel+' <a href="'+l.link+'" target="_blank" class="le-link">↗</a></span></div><a href="/afk/deletelog?id='+l.id+'" class="btn btn-danger btn-xs">✕</a></div>').join('');},5000);</script>`;
}

function buildSettings(client) {
  const allowed=rj('allowedUsers.json',{allowedUsers:[]}).allowedUsers||[];
  const rows=allowed.length?allowed.map((uid,i)=>`<tr><td style="color:var(--muted)">${i+1}</td><td><code>${esc(uid)}</code></td><td><a href="/settings/removeuser?id=${esc(uid)}" class="btn btn-danger btn-xs">Remove</a></td></tr>`).join(''):'<tr><td colspan="3" style="text-align:center;color:var(--muted);padding:20px">No allowed users</td></tr>';
  return `<div class="ph"><h1 class="pt">Settings</h1><p class="ps">Manage allowed users and bot configuration</p></div>
<div class="card"><div class="card-h"><div class="card-hl"><span class="card-ic">👥</span><span class="card-t">Allowed Users</span></div><span class="badge badge-blue">${allowed.length} users</span></div>
<div class="card-b no-pad"><div class="tbl-wrap"><table><thead><tr><th>#</th><th>User ID</th><th>Action</th></tr></thead><tbody>${rows}</tbody></table></div></div>
<div class="card-f"><form id="addFrm" style="display:flex;gap:8px;flex:1;flex-wrap:wrap"><input type="text" name="userId" placeholder="Discord User ID (17-20 digits)" style="flex:1;min-width:160px"><button type="submit" class="btn btn-primary btn-sm">Add User</button></form></div></div>
<div class="card"><div class="card-h"><div class="card-hl"><span class="card-ic">⚙️</span><span class="card-t">Bot Config</span></div></div>
<div class="card-b"><div class="info-list">
  <div class="ir"><span class="ik">Prefix</span><code>${esc(process.env.PREFIX||'!')}</code></div>
  <div class="ir"><span class="ik">Owner ID</span><code>${esc(process.env.OWNER_ID||'Not set')}</code></div>
  <div class="ir"><span class="ik">Dashboard Port</span><code>${esc(process.env.DASH_PORT||'3000')}</code></div>
  <div class="ir"><span class="ik">No-Prefix Mode</span><span class="badge ${client.db?.noPrefixMode?'badge-green':'badge-gray'}">${client.db?.noPrefixMode?'● On':'Off'}</span></div>
  <div class="ir"><span class="ik">Lavalink</span><code style="font-size:.7rem">${esc(process.env.LAVALINK_REST||'Not configured')}</code></div>
</div><p class="hint" style="margin-top:10px">Edit <code>.env</code> to change prefix, port and owner</p></div></div>
<script>document.getElementById('addFrm').addEventListener('submit',async e=>{e.preventDefault();const fd=new URLSearchParams(new FormData(e.target));await fetch('/settings/adduser',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:fd.toString()});location.reload();});</script>`;
}
