# 📺 Go Live / VC Stream Setup

Neonix can stream YouTube videos (and any yt-dlp supported URL) directly into a
Discord voice channel as a **Go Live** stream using
[@dank074/discord-video-stream](https://github.com/dank074/discord-video-stream).

---

## Prerequisites

### 1 — Node packages
```bash
npm install
```
`@dank074/discord-video-stream` is already listed in `package.json`.

### 2 — System dependencies
Both `yt-dlp` and `ffmpeg` must be in your `PATH`.

**Termux (Android):**
```bash
pkg install ffmpeg python
pip install yt-dlp
```

**Debian / Ubuntu:**
```bash
sudo apt install ffmpeg
pip install yt-dlp   # or: sudo curl -L https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -o /usr/local/bin/yt-dlp && sudo chmod +x /usr/local/bin/yt-dlp
```

**macOS:**
```bash
brew install ffmpeg yt-dlp
```

---

## Commands

| Command | Aliases | Description |
|---------|---------|-------------|
| `!stream <url>` | `!golive`, `!gl` | Start a Go Live stream (YouTube, direct mp4/rtsp, …) |
| `!streamstop` | `!glstop`, `!endstream` | Stop the active stream and leave VC |
| `!streamnp` | `!glnp`, `!nowstreaming` | Show info about the current stream |
| `!streamqueue add <url>` | `!sq add` | Add a URL to the auto-play queue |
| `!streamqueue list` | `!sq list` | Show the queue |
| `!streamqueue skip` | `!sq skip` | Skip current and play next queued item |
| `!streamqueue clear` | `!sq clear` | Clear the queue |

---

## Examples

```bash
# Stream a YouTube video
!stream https://youtu.be/dQw4w9WgXcQ

# Stream a YouTube watch URL
!stream https://www.youtube.com/watch?v=dQw4w9WgXcQ

# Stream a direct mp4
!stream https://example.com/video.mp4

# Queue multiple videos
!sq add https://youtu.be/VIDEO1
!sq add https://youtu.be/VIDEO2
!sq add https://youtu.be/VIDEO3
# → plays each automatically when the previous finishes

# Skip current in queue
!sq skip

# Stop everything
!streamstop
```

---

## How It Works

1. **Join VC** — raw Discord Gateway OP4 with `self_video: true`
2. **Resolve URL** — `yt-dlp` fetches the direct video/audio stream URL
3. **ffmpeg** — decodes + transcodes to H264 (720p30) + Opus
4. **discord-video-stream** — sends the encoded frames into the Go Live UDP stream

### Quality settings (editable in `functions/streamUtils.js`)
| Setting | Default |
|---------|---------|
| Resolution | 1280 × 720 |
| FPS | 30 |
| Video bitrate | 2500 kbps |
| Audio bitrate | 128 kbps |
| Audio sample rate | 48 000 Hz |

---

## Troubleshooting

**`yt-dlp not found`** — make sure `yt-dlp` is installed and on PATH.

**`ffmpeg not found`** — install ffmpeg for your platform (see above).

**`Timed out waiting for voice state`** — the selfbot may not have voice permissions in that channel, or the guild voice region is blocking the connection.

**Black/broken stream on Discord client** — the Go Live protocol occasionally needs the viewing client to refresh. This is a Discord-side limitation and not a Neonix bug.

**Rate limited / token flagged** — Discord's ToS prohibits selfbots. Use at your own risk.
