// ── bot/index.js — Discord Bot Controller (client2) ──────────────────────────
// A real Discord bot that lets you control the selfbot via slash commands.
// Uses discord.js v14. Token + Client ID set in .env as BOT_TOKEN / BOT_CLIENT_ID
// ─────────────────────────────────────────────────────────────────────────────
import { Client, GatewayIntentBits, REST, Routes } from 'discord.js';
import { loadAfk, saveAfk } from '../functions/afk.js';
import { loadConfig as loadRpcConfig, saveConfig as saveRpcConfig, setRichPresence } from '../commands/tools/rpc.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);
const DB         = path.join(__dirname, '..', 'database');

// ── Slash command definitions ─────────────────────────────────────────────────
export const COMMANDS = [
  // ── Status ──
  {
    name: 'status',
    description: 'Show selfbot live status',
  },
  // ── AFK ──
  {
    name: 'afk',
    description: 'Toggle AFK mode on the selfbot',
    options: [
      { type: 5, name: 'enabled', description: 'Turn AFK on or off', required: true },
      { type: 3, name: 'reason',  description: 'AFK message (optional)', required: false },
    ],
  },
  // ── RPC ──
  {
    name: 'rpc',
    description: 'Set Rich Presence on the selfbot',
    options: [
      { type: 5, name: 'enabled', description: 'Enable or disable RPC', required: true },
      {
        type: 3, name: 'type', description: 'Activity type', required: false,
        choices: [
          { name: 'Playing',   value: 'PLAYING'   },
          { name: 'Streaming', value: 'STREAMING' },
          { name: 'Listening', value: 'LISTENING' },
          { name: 'Watching',  value: 'WATCHING'  },
          { name: 'Competing', value: 'COMPETING' },
        ],
      },
      { type: 3, name: 'name',    description: 'Activity name',    required: false },
      { type: 3, name: 'details', description: 'Activity details', required: false },
      { type: 3, name: 'state',   description: 'Activity state',   required: false },
    ],
  },
  // ── AI ──
  {
    name: 'ai',
    description: 'Configure AI in a guild channel',
    options: [
      {
        type: 3, name: 'action', description: 'Action to perform', required: true,
        choices: [
          { name: 'Enable in this channel',  value: 'on'     },
          { name: 'Disable in this channel', value: 'off'    },
          { name: 'Show status',             value: 'status' },
        ],
      },
      {
        type: 3, name: 'provider', description: 'AI Provider (optional)', required: false,
        choices: [
          { name: 'Groq (llama-3.3-70b)',       value: 'groq'        },
          { name: 'OpenRouter (gpt-oss-120b)',   value: 'openrouter'  },
          { name: 'NVIDIA NIM (llama-3.3-70b)', value: 'nim'         },
        ],
      },
      {
        type: 5, name: 'respondtoall', description: 'Respond to everyone? (default: owner only)', required: false,
      },
    ],
  },
  // ── Say ──
  {
    name: 'say',
    description: 'Make the selfbot send a message in a channel',
    options: [
      { type: 3, name: 'message',    description: 'What to say',                    required: true  },
      { type: 3, name: 'channel_id', description: 'Channel ID (defaults to current)', required: false },
    ],
  },
  // ── Music ──
  {
    name: 'music',
    description: 'Control selfbot music player',
    options: [
      {
        type: 3, name: 'action', description: 'Action', required: true,
        choices: [
          { name: 'Now Playing', value: 'np'       },
          { name: 'Skip',        value: 'skip'     },
          { name: 'Stop',        value: 'stop'     },
          { name: 'Pause',       value: 'pause'    },
          { name: 'Resume',      value: 'resume'   },
          { name: 'Queue',       value: 'queue'    },
        ],
      },
    ],
  },
  // ── Purge selfbot messages ──
  {
    name: 'purge',
    description: 'Delete selfbot\'s recent messages in a channel',
    options: [
      { type: 4, name: 'count',      description: 'Number of messages to delete (1-50)', required: true },
      { type: 3, name: 'channel_id', description: 'Channel ID (defaults to current)',      required: false },
    ],
  },
  // ── Eval (owner only) ──
  {
    name: 'eval',
    description: '[OWNER ONLY] Evaluate JS on the selfbot',
    options: [
      { type: 3, name: 'code', description: 'JavaScript code to evaluate', required: true },
    ],
  },
];

// ── White embed builder ───────────────────────────────────────────────────────
function embed(title, description, fields = [], footer = 'Neonix Controller') {
  return {
    embeds: [{
      color: 0xFFFFFF,  // white
      title: title ? `✦ ${title}` : undefined,
      description,
      fields: fields.map(([name, value, inline = false]) => ({ name, value: String(value), inline })),
      footer: { text: footer },
      timestamp: new Date().toISOString(),
    }],
    flags: 64, // ephemeral
  };
}

function embedOk(title, desc, fields)  { return embed(title, desc, fields); }
function embedErr(msg)                  { return embed('Error', `❌ ${msg}`); }

// ── Register slash commands with Discord API ──────────────────────────────────
export async function registerCommands() {
  const token    = process.env.BOT_TOKEN;
  const clientId = process.env.BOT_CLIENT_ID;
  if (!token || !clientId) return;

  const rest = new REST({ version: '10' }).setToken(token);
  try {
    await rest.put(Routes.applicationCommands(clientId), { body: COMMANDS });
    console.log('[Bot] Slash commands registered globally');
  } catch (e) {
    console.error('[Bot] Failed to register commands:', e.message);
  }
}

// ── Start bot ─────────────────────────────────────────────────────────────────
export function startBotController(selfbot, lavalink, queueManager, voiceStates) {
  const token    = process.env.BOT_TOKEN;
  const clientId = process.env.BOT_CLIENT_ID;
  const ownerId  = process.env.OWNER_ID;

  if (!token || !clientId) {
    console.log('[Bot] BOT_TOKEN or BOT_CLIENT_ID not set — bot controller disabled');
    return;
  }

  const bot = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
    ],
  });

  // ── Helpers ─────────────────────────────────────────────────────────────────
  function rj(file, def = {}) {
    try { return JSON.parse(fs.readFileSync(path.join(DB, file), 'utf8')); } catch { return def; }
  }
  function wj(file, data) {
    fs.writeFileSync(path.join(DB, file), JSON.stringify(data, null, 2));
  }

  function getMusicStatus() {
    for (const [gId, q] of queueManager.getAll()) {
      if (!q.nowPlaying) continue;
      const info = q.nowPlaying.info;
      let pos = q.position || 0;
      if (q.lastUpdate && !q.paused) pos += Date.now() - q.lastUpdate;
      return { gId, info, pos, queue: q.songs, paused: q.paused };
    }
    return null;
  }

  function fmtMs(ms) {
    if (!ms) return '0:00';
    const s = Math.floor(ms / 1000), m = Math.floor(s / 60);
    return `${m}:${String(s % 60).padStart(2, '0')}`;
  }

  // ── Interaction handler ──────────────────────────────────────────────────────
  bot.on('interactionCreate', async (interaction) => {
    if (!interaction.isChatInputCommand()) return;

    const { commandName, options, user, channelId, guildId } = interaction;

    await interaction.deferReply({ ephemeral: true }).catch(() => {});

    try {
      // ── /status ────────────────────────────────────────────────────────────
      if (commandName === 'status') {
        const afk      = loadAfk();
        const rpc      = loadRpcConfig();
        const aiCfg    = rj('ai_config.json');
        const upSec    = Math.floor(process.uptime());
        const h = Math.floor(upSec / 3600), m = Math.floor((upSec % 3600) / 60), s = upSec % 60;
        const uptime   = `${h}h ${String(m).padStart(2,'0')}m ${String(s).padStart(2,'0')}s`;
        const music    = getMusicStatus();
        const guilds   = selfbot.guilds?.cache?.size ?? 0;
        const cmds     = selfbot.commands?.size ?? 0;
        const aiEnabled = Object.values(aiCfg).filter(c => c.enabled).length;

        return interaction.editReply(embedOk('Selfbot Status', null, [
          ['👤 Account',   selfbot.user?.username ?? '—', true],
          ['🌐 Servers',   guilds,                        true],
          ['⚡ Commands',  cmds,                          true],
          ['⏱️ Uptime',   uptime,                        true],
          ['😴 AFK',       afk.isOn ? `On — "${afk.reason}"` : 'Off', true],
          ['🎭 RPC',       rpc.enabled ? `${rpc.type}: ${rpc.name}` : 'Off', true],
          ['🤖 AI Guilds', aiEnabled,                     true],
          ['🎵 Music',     music ? `▶ ${music.info.title}` : 'Idle', true],
          ['💻 Memory',    Math.round(process.memoryUsage().heapUsed / 1024 / 1024) + 'MB', true],
        ]));
      }

      // ── /afk ───────────────────────────────────────────────────────────────
      if (commandName === 'afk') {
        const enabled = options.getBoolean('enabled');
        const reason  = options.getString('reason') || 'I am currently AFK.';
        const afk     = loadAfk();
        afk.isOn      = enabled;
        if (enabled) afk.reason = reason;
        saveAfk(afk);

        return interaction.editReply(embedOk(
          'AFK Updated',
          enabled ? `✅ AFK **enabled**\nMessage: *${reason}*` : '❌ AFK **disabled**',
        ));
      }

      // ── /rpc ───────────────────────────────────────────────────────────────
      if (commandName === 'rpc') {
        const enabled = options.getBoolean('enabled');
        const cfg     = loadRpcConfig();
        cfg.enabled   = enabled;
        if (options.getString('type'))    cfg.type    = options.getString('type');
        if (options.getString('name'))    cfg.name    = options.getString('name');
        if (options.getString('details')) cfg.details = options.getString('details');
        if (options.getString('state'))   cfg.state   = options.getString('state');
        saveRpcConfig(cfg);
        try { await setRichPresence(selfbot, cfg); } catch {}

        return interaction.editReply(embedOk(
          'Rich Presence Updated',
          enabled
            ? `✅ RPC **enabled**\n**${cfg.type}** ${cfg.name || ''}${cfg.details ? `\n${cfg.details}` : ''}`
            : '❌ RPC **disabled**',
        ));
      }

      // ── /ai ────────────────────────────────────────────────────────────────
      if (commandName === 'ai') {
        const action  = options.getString('action');
        const provider = options.getString('provider');
        const rta     = options.getBoolean('respondtoall');
        const aiCfg   = rj('ai_config.json');
        const gId     = guildId;

        if (!aiCfg[gId]) aiCfg[gId] = { enabled: false, channels: [], respondToAll: false, provider: 'groq' };

        if (action === 'on') {
          if (!aiCfg[gId].channels.includes(channelId)) aiCfg[gId].channels.push(channelId);
          aiCfg[gId].enabled = true;
          if (provider) aiCfg[gId].provider = provider;
          if (rta !== null) aiCfg[gId].respondToAll = rta;
          wj('ai_config.json', aiCfg);
          return interaction.editReply(embedOk('AI Enabled', `✅ AI active in <#${channelId}>\n**Provider:** ${aiCfg[gId].provider}\n**Respond to all:** ${aiCfg[gId].respondToAll ? 'Yes' : 'No'}`));
        }

        if (action === 'off') {
          aiCfg[gId].channels = aiCfg[gId].channels.filter(c => c !== channelId);
          if (!aiCfg[gId].channels.length) aiCfg[gId].enabled = false;
          wj('ai_config.json', aiCfg);
          return interaction.editReply(embedOk('AI Disabled', `❌ AI disabled in <#${channelId}>`));
        }

        if (action === 'status') {
          const c = aiCfg[gId];
          return interaction.editReply(embedOk('AI Status', null, [
            ['Enabled',       c.enabled ? '✅ Yes' : '❌ No', true],
            ['Provider',      c.provider || 'groq',            true],
            ['Active Channels', c.channels.length,             true],
            ['Respond to All', c.respondToAll ? '✅ Yes' : '❌ No', true],
          ]));
        }
      }

      // ── /say ───────────────────────────────────────────────────────────────
      if (commandName === 'say') {
        const message   = options.getString('message');
        const targetCh  = options.getString('channel_id') || channelId;
        const ch        = selfbot.channels.cache.get(targetCh);
        if (!ch) return interaction.editReply(embedErr(`Channel \`${targetCh}\` not found in selfbot's cache`));
        await ch.send(message);
        return interaction.editReply(embedOk('Message Sent', `✅ Sent to <#${targetCh}>\n> ${message.slice(0, 200)}`));
      }

      // ── /music ─────────────────────────────────────────────────────────────
      if (commandName === 'music') {
        const action = options.getString('action');
        const music  = getMusicStatus();

        if (action === 'np') {
          if (!music) return interaction.editReply(embedOk('Music', '🎵 Nothing is playing right now'));
          const pct = music.info.length ? Math.round((music.pos / music.info.length) * 20) : 0;
          const bar = '▓'.repeat(pct) + '░'.repeat(20 - pct);
          return interaction.editReply(embedOk('Now Playing', null, [
            ['🎵 Title',   music.info.title,  false],
            ['👤 Artist',  music.info.author, true],
            ['⏱️ Progress', `\`${fmtMs(music.pos)} ${bar} ${fmtMs(music.info.length)}\``, false],
            ['📋 Queue',   `${music.queue.length} song(s) remaining`, true],
            ['⏯️ State',   music.paused ? 'Paused' : 'Playing', true],
          ]));
        }

        if (!music && action !== 'np') return interaction.editReply(embedErr('No music is playing'));

        if (action === 'skip') {
          const next = queueManager.getNext(music.gId);
          if (!next) {
            if (lavalink) await lavalink.destroyPlayer(music.gId).catch(() => {});
            queueManager.delete(music.gId);
          } else {
            const q = queueManager.get(music.gId);
            if (q.history) q.history.push(q.nowPlaying);
            q.nowPlaying = next; q.position = 0; q.lastUpdate = Date.now();
            const vs = voiceStates[music.gId];
            if (vs && lavalink) await lavalink.updatePlayer(music.gId, next, vs).catch(() => {});
          }
          return interaction.editReply(embedOk('Music', '⏭️ Skipped to next track'));
        }

        if (action === 'stop') {
          if (lavalink) await lavalink.destroyPlayer(music.gId).catch(() => {});
          queueManager.delete(music.gId);
          return interaction.editReply(embedOk('Music', '⏹️ Music stopped'));
        }

        if (action === 'pause') {
          const q = queueManager.get(music.gId);
          if (q) { q.paused = true; }
          if (lavalink) await lavalink.pausePlayer(music.gId, true).catch(() => {});
          return interaction.editReply(embedOk('Music', '⏸️ Paused'));
        }

        if (action === 'resume') {
          const q = queueManager.get(music.gId);
          if (q) { q.paused = false; q.lastUpdate = Date.now(); }
          if (lavalink) await lavalink.pausePlayer(music.gId, false).catch(() => {});
          return interaction.editReply(embedOk('Music', '▶️ Resumed'));
        }

        if (action === 'queue') {
          if (!music) return interaction.editReply(embedOk('Queue', 'Queue is empty'));
          const lines = music.queue.slice(0, 10).map((s, i) => `**${i + 1}.** ${s.info.title}`).join('\n');
          return interaction.editReply(embedOk('Queue', lines || 'No upcoming songs', [
            ['Total', music.queue.length + ' songs', true],
          ]));
        }
      }

      // ── /purge ─────────────────────────────────────────────────────────────
      if (commandName === 'purge') {
        const count    = Math.min(Math.max(options.getInteger('count'), 1), 50);
        const targetCh = options.getString('channel_id') || channelId;
        const ch       = selfbot.channels.cache.get(targetCh);
        if (!ch) return interaction.editReply(embedErr(`Channel \`${targetCh}\` not found`));

        const msgs = await ch.messages.fetch({ limit: 100 });
        const mine = [...msgs.values()]
          .filter(m => m.author.id === selfbot.user.id)
          .slice(0, count);

        let deleted = 0;
        for (const m of mine) {
          await m.delete().catch(() => {});
          deleted++;
          await new Promise(r => setTimeout(r, 300));
        }
        return interaction.editReply(embedOk('Purge', `🗑️ Deleted **${deleted}** of my messages in <#${targetCh}>`));
      }

      // ── /eval (owner only) ─────────────────────────────────────────────────
      if (commandName === 'eval') {
        if (user.id !== ownerId) return interaction.editReply(embedErr('Owner only command'));
        const code = options.getString('code');
        try {
          // eslint-disable-next-line no-eval
          let result = eval(code);
          if (result instanceof Promise) result = await result;
          const out = String(result ?? 'undefined').slice(0, 1800);
          return interaction.editReply(embedOk('Eval', `\`\`\`js\n${out}\n\`\`\``));
        } catch (e) {
          return interaction.editReply(embedErr(`\`\`\`js\n${e.message}\n\`\`\``));
        }
      }

    } catch (err) {
      console.error('[Bot] Command error:', err);
      interaction.editReply(embedErr(err.message)).catch(() => {});
    }
  });

  bot.once('ready', () => {
    console.log(`[Bot] Controller online as ${bot.user.tag}`);
  });

  bot.on('error', err => console.error('[Bot] Error:', err.message));

  bot.login(token).catch(err => console.error('[Bot] Login failed:', err.message));

  return bot;
}
