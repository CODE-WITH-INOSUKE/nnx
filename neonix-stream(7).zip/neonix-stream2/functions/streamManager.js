/**
 * streamManager.js
 * Per-guild stream session store.
 */

import { cleanupStream } from './streamUtils.js';

const sessions = new Map();

export class StreamSession {
  constructor(guildId) {
    this.guildId     = guildId;
    this.channelId   = null;
    this.url         = null;
    this.title       = null;
    this.streamer    = null;
    this.command     = null;
    this.textChannel = null;
    this.startedAt   = Date.now();
  }

  async destroy(client) {
    console.log(`[StreamManager] Destroying guild=${this.guildId}`);
    await cleanupStream(client, this.guildId, this.channelId, this.streamer, this.command);
    sessions.delete(this.guildId);
  }
}

export default {
  get(guildId)          { return sessions.get(guildId); },
  has(guildId)          { return sessions.has(guildId); },
  set(guildId, session) { sessions.set(guildId, session); },
  async destroy(guildId, client) {
    const s = sessions.get(guildId);
    if (s) await s.destroy(client);
    sessions.delete(guildId);
  },
  all() { return [...sessions.values()]; },
};
