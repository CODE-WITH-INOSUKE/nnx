import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const AI_CONFIG_FILE = path.join(__dirname, '..', '..', 'database', 'ai_config.json');

const VALID_PROVIDERS = ['groq', 'openrouter', 'or', 'nim', 'nvidia'];
const PROVIDER_LABELS = {
  groq:        'Groq (llama-3.3-70b-versatile)',
  openrouter:  'OpenRouter (gpt-oss-120b:free)',
  nim:         'NVIDIA NIM (llama-3.3-70b-instruct)',
};

function normalizeProvider(p) {
  if (p === 'or') return 'openrouter';
  if (p === 'nvidia') return 'nim';
  return p;
}

function loadAIConfig() {
  try {
    if (fs.existsSync(AI_CONFIG_FILE)) return JSON.parse(fs.readFileSync(AI_CONFIG_FILE, 'utf8'));
  } catch (e) { console.error('[AI Config] Error loading:', e); }
  return {};
}

function saveAIConfig(data) {
  try { fs.writeFileSync(AI_CONFIG_FILE, JSON.stringify(data, null, 2)); }
  catch (e) { console.error('[AI Config] Error saving:', e); }
}

export default {
  name: 'ai',
  aliases: ['aiconfig', 'aic'],
  category: 'ai',
  description: 'Configure AI settings per guild',
  usage: 'ai <on/off/respondtoall/provider/status>',

  async execute(message, args, client) {
    if (!message.guild) return message.channel.send('```\nUse this command in a server.\n```');

    const guildId   = message.guild.id;
    const channelId = message.channel.id;
    const sub       = args[0]?.toLowerCase();
    const config    = loadAIConfig();

    if (!config[guildId]) {
      config[guildId] = { enabled: false, channels: [], respondToAll: false, provider: 'groq' };
    }

    if (!sub) {
      return message.channel.send([
        '```',
        '╭─[ AI CONFIG ]─╮\n',
        '  ai on                    — Enable AI in this channel',
        '  ai off                   — Disable AI in this channel',
        '  ai respondtoall <on/off> — Reply to everyone or just owner',
        '  ai provider <groq/openrouter/nim>',
        '  ai status                — Show current config',
        '\n╰──────────────────────────────╯',
        '```',
      ].join('\n'));
    }

    // ── on ──
    if (['on', 'enable'].includes(sub)) {
      if (!config[guildId].channels.includes(channelId)) config[guildId].channels.push(channelId);
      config[guildId].enabled = true;
      saveAIConfig(config);
      const prov = config[guildId].provider || 'groq';
      return message.channel.send([
        '```',
        '╭─[ AI ENABLED ]─╮\n',
        `  Channel:  #${message.channel.name}`,
        `  Provider: ${PROVIDER_LABELS[prov] || prov}`,
        `  All users: ${config[guildId].respondToAll ? 'Yes' : 'No (owner/allowed only)'}`,
        '\n  Mention me to chat!',
        '\n╰──────────────────────────────╯',
        '```',
      ].join('\n'));
    }

    // ── off ──
    if (['off', 'disable'].includes(sub)) {
      config[guildId].channels = config[guildId].channels.filter(id => id !== channelId);
      if (config[guildId].channels.length === 0) config[guildId].enabled = false;
      saveAIConfig(config);
      return message.channel.send('```\n✅ AI disabled in this channel.\n```');
    }

    // ── respondtoall ──
    if (sub === 'respondtoall') {
      const mode = args[1]?.toLowerCase();
      if (!['on', 'off'].includes(mode))
        return message.channel.send('```\nUsage: ai respondtoall <on/off>\n```');
      config[guildId].respondToAll = mode === 'on';
      saveAIConfig(config);
      return message.channel.send([
        '```',
        `╭─[ RESPOND TO ALL: ${mode.toUpperCase()} ]─╮\n`,
        config[guildId].respondToAll
          ? '  AI will respond to everyone.'
          : '  AI will only respond to owner and allowed users.',
        '\n╰──────────────────────────────╯',
        '```',
      ].join('\n'));
    }

    // ── provider ──
    if (sub === 'provider') {
      const raw = args[1]?.toLowerCase();
      if (!raw || !VALID_PROVIDERS.includes(raw)) {
        const cur = config[guildId].provider || 'groq';
        return message.channel.send([
          '```',
          '╭─[ AI PROVIDERS ]─╮\n',
          '  groq        — Groq (llama-3.3-70b-versatile)',
          '  openrouter  — OpenRouter (gpt-oss-120b:free)',
          '  nim         — NVIDIA NIM (llama-3.3-70b-instruct)',
          `\n  Current: ${PROVIDER_LABELS[cur] || cur}`,
          '  Usage:   ai provider <groq/openrouter/nim>',
          '\n╰──────────────────────────────╯',
          '```',
        ].join('\n'));
      }
      const provider = normalizeProvider(raw);
      config[guildId].provider = provider;
      saveAIConfig(config);
      return message.channel.send([
        '```',
        '╭─[ PROVIDER UPDATED ]─╮\n',
        `  Provider: ${PROVIDER_LABELS[provider] || provider}`,
        '\n╰──────────────────────────────╯',
        '```',
      ].join('\n'));
    }

    // ── status ──
    if (sub === 'status') {
      const c = config[guildId];
      const prov = c.provider || 'groq';
      return message.channel.send([
        '```',
        '╭─[ AI STATUS ]─╮\n',
        `  Enabled:     ${c.enabled ? '✅ Yes' : '❌ No'}`,
        `  Provider:    ${PROVIDER_LABELS[prov] || prov}`,
        `  Channels:    ${c.channels.length} active`,
        `  All users:   ${c.respondToAll ? '✅ Yes' : '❌ No'}`,
        '\n╰──────────────────────────────╯',
        '```',
      ].join('\n'));
    }

    return message.channel.send('```\n❌ Unknown subcommand. Use: ai on/off/respondtoall/provider/status\n```');
  },
};
