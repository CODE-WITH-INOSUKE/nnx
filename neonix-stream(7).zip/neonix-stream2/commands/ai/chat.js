import Groq from 'groq-sdk';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);

const DB           = path.join(__dirname, '..', '..', 'database');
const CONFIG_FILE  = path.join(DB, 'ai_config.json');
const PERS_FILE    = path.join(DB, 'personality.txt');
const ALLOWED_FILE = path.join(DB, 'allowedUsers.json');
const BLOCKED_FILE = path.join(DB, 'ai_blocked.json');

if (!fs.existsSync(DB)) fs.mkdirSync(DB, { recursive: true });
if (!fs.existsSync(PERS_FILE)) fs.writeFileSync(PERS_FILE, 'You are a helpful, friendly AI assistant.');

// ── Lazy SDK clients ──────────────────────────────────────────────────────────
let _groq = null;
function getGroq() {
  if (!_groq) _groq = new Groq({ apiKey: process.env.GROQ_API_KEY });
  return _groq;
}

// ── Config loaders ────────────────────────────────────────────────────────────
function loadConfig()    { try { return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')); } catch { return {}; } }
function loadPersonality() { try { return fs.readFileSync(PERS_FILE, 'utf8'); } catch { return 'You are a helpful AI assistant.'; } }
function loadAllowed()   { try { return JSON.parse(fs.readFileSync(ALLOWED_FILE, 'utf8')).allowedUsers || []; } catch { return []; } }
function loadBlocked()   { try { return JSON.parse(fs.readFileSync(BLOCKED_FILE, 'utf8')); } catch { return {}; } }

function isAllowed(userId) {
  if (userId === process.env.OWNER_ID) return true;
  return loadAllowed().includes(userId);
}

// ── Conversation history (channelId → messages[]) ────────────────────────────
const history = new Map();

function getHistory(channelId, systemPrompt) {
  if (!history.has(channelId)) history.set(channelId, [{ role: 'system', content: systemPrompt }]);
  return history.get(channelId);
}

// ── AI provider calls ─────────────────────────────────────────────────────────
async function callGroq(messages) {
  const res = await getGroq().chat.completions.create({
    model: 'llama-3.3-70b-versatile',
    messages, temperature: 0.7, max_tokens: 1024, stream: false,
  });
  return res.choices[0]?.message?.content || 'No response.';
}

async function callOpenRouter(messages) {
  const r = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
      'Content-Type': 'application/json',
      'HTTP-Referer': 'https://neonix.local',
      'X-Title': 'Neonix',
    },
    body: JSON.stringify({ model: 'openai/gpt-oss-120b:free', messages, temperature: 0.7, max_tokens: 1024 }),
  });
  const d = await r.json();
  if (d.error) throw new Error(d.error.message || JSON.stringify(d.error));
  return d.choices?.[0]?.message?.content || 'No response.';
}

async function callNIM(messages) {
  const r = await fetch('https://integrate.api.nvidia.com/v1/chat/completions', {
    method: 'POST',
    headers: { Authorization: `Bearer ${process.env.NVIDIA_NIM_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: 'meta/llama-3.3-70b-instruct', messages, temperature: 0.7, max_tokens: 1024 }),
  });
  return (await r.json()).choices?.[0]?.message?.content || 'No response.';
}

async function getResponse(userMsg, channelId, provider = 'groq') {
  const sys  = loadPersonality();
  const msgs = getHistory(channelId, sys);
  msgs.push({ role: 'user', content: userMsg });
  if (msgs.length > 21) msgs.splice(1, msgs.length - 21);

  let reply;
  switch (provider) {
    case 'openrouter': case 'or': reply = await callOpenRouter(msgs); break;
    case 'nim': case 'nvidia':    reply = await callNIM(msgs); break;
    default:                      reply = await callGroq(msgs);
  }
  msgs.push({ role: 'assistant', content: reply });
  return reply;
}

function splitMsg(text, max = 1990) {
  if (text.length <= max) return [text];
  const parts = []; let cur = '';
  for (const line of text.split('\n')) {
    if ((cur + line + '\n').length > max) { if (cur) parts.push(cur.trim()); cur = line + '\n'; }
    else cur += line + '\n';
  }
  if (cur) parts.push(cur.trim());
  return parts;
}

// ── chat command ──────────────────────────────────────────────────────────────
export default {
  name: 'chat',
  aliases: ['ask'],
  category: 'ai',
  description: 'Chat with AI',
  usage: 'chat <message>',

  async execute(message, args, client) {
    if (!args.length) return message.channel.send('```\nUsage: chat <message>\n```');

    const cfg      = loadConfig();
    const provider = cfg[message.guild?.id]?.provider || 'groq';

    // Show typing indicator
    await message.channel.sendTyping().catch(() => {});

    try {
      const reply = await getResponse(args.join(' '), message.channel.id, provider);
      for (const part of splitMsg(reply)) await message.reply(part);
    } catch (e) {
      console.error('[AI chat]', e);
      await message.channel.send(`\`\`\`\n❌ AI Error: ${e.message}\n\`\`\``);
    }
  },
};

// ── Mention listener ──────────────────────────────────────────────────────────
export function registerAIListener(client) {
  console.log('[AI] Mention listener registered');

  client.on('messageCreate', async (message) => {
    if (!message.guild) return;
    if (message.author.id === client.user.id) return;
    if (!message.mentions.has(client.user.id)) return;

    const guildId   = message.guild.id;
    const channelId = message.channel.id;
    const cfg       = loadConfig();
    const gCfg      = cfg[guildId];

    if (!gCfg?.enabled) return;
    if (!gCfg.channels.includes(channelId)) return;

    const blocked = loadBlocked();
    if (blocked[guildId]?.includes(message.author.id)) {
      await message.reply('```\n❌ You are blocked from using AI chat.\n```');
      return;
    }

    if (!gCfg.respondToAll && !isAllowed(message.author.id)) return;

    const userMsg = message.content.replace(/<@!?\d+>/g, '').trim();
    if (!userMsg) return;

    // Show typing indicator while AI generates
    const stopTyping = setInterval(() => message.channel.sendTyping().catch(() => {}), 5000);
    await message.channel.sendTyping().catch(() => {});

    try {
      const provider = gCfg.provider || 'groq';
      console.log(`[AI] @mention — provider: ${provider}, user: ${message.author.tag}`);
      const reply = await getResponse(userMsg, channelId, provider);
      clearInterval(stopTyping);
      for (const part of splitMsg(reply)) await message.reply(part);
    } catch (e) {
      clearInterval(stopTyping);
      console.error('[AI] mention error:', e);
      await message.channel.send(`\`\`\`\n❌ AI Error: ${e.message}\n\`\`\``);
    }
  });
}

export async function initializeAI(client) {
  const cfg = loadConfig();
  const enabled = Object.values(cfg).filter(c => c.enabled).length;
  registerAIListener(client);
  console.log(`[AI] Ready — ${enabled} guild(s) enabled`);
}

export { history as conversationHistory };
