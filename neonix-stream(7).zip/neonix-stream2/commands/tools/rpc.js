import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const CONFIG_PATH = path.join(__dirname, '..', '..', 'database');
const CONFIG_FILE = path.join(CONFIG_PATH, 'rpcConfig.json');

const defaultConfig = {
  enabled: false, type: null, name: null, details: null, state: null,
  imageUrl: null, imageText: null, smallImageUrl: null, smallImageText: null,
  button1Label: null, button1Url: null, button2Label: null, button2Url: null
};

const VALID_TYPES = ['PLAYING', 'STREAMING', 'LISTENING', 'WATCHING', 'COMPETING'];
const ACTIVITY_TYPES = { PLAYING: 0, STREAMING: 1, LISTENING: 2, WATCHING: 3, COMPETING: 5 };

if (!fs.existsSync(CONFIG_PATH)) fs.mkdirSync(CONFIG_PATH, { recursive: true });

export function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_FILE))
      return { ...defaultConfig, ...JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')) };
  } catch (e) { console.error('[RPC] Error loading config:', e); }
  return { ...defaultConfig };
}

export function saveConfig(config) {
  try { fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2)); }
  catch (e) { console.error('[RPC] Error saving config:', e); }
}

function isDiscordCdn(u) {
  try { return new URL(u).hostname === 'cdn.discordapp.com'; } catch { return false; }
}

export async function setRichPresence(client, config) {
  try {
    if (!config.enabled || !config.type || !config.name) {
      await client.user.setActivity(null);
      console.log('[RPC] Cleared');
      return;
    }

    // Build using the raw presence format that selfbot-v13 actually accepts for buttons
    const activity = {
      name: config.name,
      type: ACTIVITY_TYPES[config.type] ?? 0,
    };

    if (config.type === 'STREAMING') activity.url = 'https://twitch.tv/discord';
    if (config.details) activity.details = config.details;
    if (config.state)   activity.state   = config.state;

    // Assets (images)
    const assets = {};
    if (config.imageUrl && isDiscordCdn(config.imageUrl)) {
      assets.large_image = config.imageUrl;
      assets.large_text  = config.imageText || config.name;
    }
    if (config.smallImageUrl && isDiscordCdn(config.smallImageUrl)) {
      assets.small_image = config.smallImageUrl;
      assets.small_text  = config.smallImageText || '';
    }
    if (Object.keys(assets).length) activity.assets = assets;

    // Buttons — selfbot-v13 requires the metadata.button_urls format
    const buttonLabels = [];
    const buttonUrls   = [];
    if (config.button1Label?.trim() && config.button1Url?.trim()) {
      buttonLabels.push(config.button1Label.trim());
      buttonUrls.push(config.button1Url.trim());
    }
    if (config.button2Label?.trim() && config.button2Url?.trim()) {
      buttonLabels.push(config.button2Label.trim());
      buttonUrls.push(config.button2Url.trim());
    }
    if (buttonLabels.length) {
      activity.buttons  = buttonLabels;
      activity.metadata = { button_urls: buttonUrls };
    }

    await client.user.setPresence({ activities: [activity] });
    console.log(`[RPC] Set: ${config.type} "${config.name}" ${buttonLabels.length ? `(${buttonLabels.length} button${buttonLabels.length > 1 ? 's' : ''})` : ''}`);
  } catch (error) {
    console.error('[RPC] Error setting presence:', error);
    throw error;
  }
}

export default {
  name: 'rpc',
  aliases: ['status', 'presence'],
  category: 'utility',
  description: 'Configure Rich Presence status',
  usage: 'rpc <on/off/TYPE> [text] [cdn.discordapp.com imageURL]',

  async execute(message, args, client) {
    const config = loadConfig();

    if (!args.length) {
      return message.channel.send([
        '```',
        '╭─[ RPC CONFIG ]─╮\n',
        '  rpc <TYPE> <text> [cdn.discordapp.com imageURL]',
        '  rpc on   — re-enable saved activity',
        '  rpc off  — disable activity\n',
        '  Types: ' + VALID_TYPES.join(', ') + '\n',
        '  Tip: Use localhost:3000/rpc for full config with buttons',
        '\n╰──────────────────────────────────╯',
        '```',
      ].join('\n'));
    }

    const sub = args[0].toUpperCase();

    try {
      if (sub === 'OFF') {
        config.enabled = false; saveConfig(config); await setRichPresence(client, config);
        return message.channel.send('```\n⏹️  RPC disabled.\n```');
      }

      if (sub === 'ON') {
        if (!config.type || !config.name) {
          return message.channel.send(['```', '❌ No activity configured yet.\n', '  Use: rpc PLAYING Minecraft\n  Or: localhost:3000/rpc', '```'].join('\n'));
        }
        config.enabled = true; saveConfig(config); await setRichPresence(client, config);
        return message.channel.send(['```', '╭─[ RPC ENABLED ]─╮\n', `  Type:  ${config.type}`, `  Text:  ${config.name}`, `  Image: ${config.imageUrl ?? 'None'}`, '  Status: Enabled ✅', '\n╰──────────────────────────────────╯', '```'].join('\n'));
      }

      if (!VALID_TYPES.includes(sub))
        return message.channel.send(`\`\`\`\n❌ Invalid type. Use: ${VALID_TYPES.join(', ')}\n\`\`\``);

      if (args.length < 2)
        return message.channel.send('```\n❌ Status text cannot be empty.\n```');

      const lastArg = args[args.length - 1];
      const hasImage = isDiscordCdn(lastArg);

      if (!hasImage && lastArg.startsWith('http'))
        return message.channel.send('```\n❌ Only cdn.discordapp.com image links are supported.\n```');

      config.type    = sub;
      config.name    = hasImage ? args.slice(1, -1).join(' ') : args.slice(1).join(' ');
      config.imageUrl = hasImage ? lastArg : null;
      config.enabled = true;

      if (!config.name)
        return message.channel.send('```\n❌ Status text cannot be empty.\n```');

      saveConfig(config); await setRichPresence(client, config);
      return message.channel.send(['```', '╭─[ RPC UPDATED ]─╮\n', `  Type:  ${config.type}`, `  Text:  ${config.name}`, `  Image: ${config.imageUrl ?? 'None'}`, '  Status: Enabled ✅', '\n╰──────────────────────────────────╯', '```'].join('\n'));
    } catch (error) {
      console.error('[RPC] Command error:', error);
      await message.channel.send(`\`\`\`\n❌ RPC Error: ${error.message}\n\`\`\``);
    }
  },
};

export async function initializeRPC(client) {
  console.log('[RPC] Initializing Rich Presence...');
  try { await setRichPresence(client, loadConfig()); }
  catch (e) { console.error('[RPC] Failed to initialize:', e); }
}
