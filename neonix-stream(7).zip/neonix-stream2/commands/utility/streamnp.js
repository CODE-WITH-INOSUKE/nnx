/**
 * commands/utility/streamnp.js
 */

import streamManager from '../../functions/streamManager.js';

function fmt(ms) {
  const s = Math.floor(ms / 1000), m = Math.floor(s / 60), h = Math.floor(m / 60);
  if (h) return `${h}h ${m % 60}m ${s % 60}s`;
  if (m) return `${m}m ${s % 60}s`;
  return `${s}s`;
}

export default {
  name:        'streamnp',
  aliases:     ['glnp', 'camnp', 'nowstreaming', 'streaminfo'],
  category:    'utility',
  description: 'Show info about the active stream',
  usage:       'streamnp',

  async execute(message, args, client) {
    if (!message.guild) return message.channel.send('```\n❌ Server only.\n```');
    const s = streamManager.get(message.guild.id);
    if (!s) return message.channel.send('```\n❌ Nothing streaming.\n```');
    const vc = client.guilds.cache.get(message.guild.id)?.channels.cache.get(s.channelId);
    await message.channel.send([
      '```',
      '╭─[ NOW STREAMING ]─────────────────╮',
      `  📺 ${s.title ?? 'Unknown'}`,
      `  🔊 ${vc?.name ?? s.channelId}`,
      '  📡 Go Live · 480p · 24fps',
      `  ⏱️  Uptime: ${fmt(Date.now() - s.startedAt)}`,
      `  🔗 ${s.url}`,
      '╰──────────────────────────────────╯',
      '```',
    ].join('\n'));
    if (message.deletable) message.delete().catch(() => {});
  },
};
