import OpenAI from 'openai';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { MessageAttachment } from 'discord.js-selfbot-v13';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function parseFiles(content) {
  const files = [];
  const lines = content.split('\n');
  let current = null, codeLines = [];
  for (const line of lines) {
    const m = line.match(/\/\/\s*FILE:\s*(.+\.\w+)/i) || line.match(/#\s*FILE:\s*(.+\.\w+)/i);
    if (m) {
      if (current && codeLines.length) files.push({ name: current, code: codeLines.join('\n') });
      current = m[1].trim(); codeLines = [];
    } else if (current) codeLines.push(line);
  }
  if (current && codeLines.length) files.push({ name: current, code: codeLines.join('\n') });
  if (!files.length) files.push({ name: 'output.txt', code: content });
  return files;
}

export default {
  name: 'code',
  aliases: ['codeagent', 'build'],
  category: 'utility',
  description: 'Generate code/apps with AI Code Agent',
  usage: 'code <prompt>',
  async execute(message, args, client) {
    if (!args.length) return message.channel.send('```\n❌ Usage: code <what to build>\n```');
    if (!process.env.NVIDIA_NIM_API_KEY) return message.channel.send('```\n❌ NVIDIA_NIM_API_KEY not set in .env\n```');

    const prompt = args.join(' ');
    const waitMsg = await message.channel.send(['```', '╭─[ CODE AGENT ]─╮', `  🤖 Generating: ${prompt.slice(0,60)}…`, '  ⏳ Please wait…', '╰──────────────────╯', '```'].join('\n'));

    try {
      const openai = new OpenAI({ apiKey: process.env.NVIDIA_NIM_API_KEY, baseURL: 'https://integrate.api.nvidia.com/v1' });
      let content = '';
      const stream = await openai.chat.completions.create({
        model: 'z-ai/glm5',
        messages: [{ role: 'user', content: `You are an expert programmer. Build: ${prompt}\n\nFor each file, start with: // FILE: filename.ext\nWrite complete working code.` }],
        temperature: 1, top_p: 1, max_tokens: 16384,
        chat_template_kwargs: { enable_thinking: true, clear_thinking: false },
        stream: true
      });
      for await (const chunk of stream) content += chunk.choices[0]?.delta?.content || '';

      const files = parseFiles(content);
      const tmpDir = path.join(__dirname, '..', '..', 'temp_code_' + Date.now());
      fs.mkdirSync(tmpDir, { recursive: true });
      files.forEach(f => fs.writeFileSync(path.join(tmpDir, f.name), f.code));

      if (files.length === 1) {
        const att = new MessageAttachment(Buffer.from(files[0].code), files[0].name);
        await waitMsg.edit({ content: ['```', `╭─[ CODE AGENT ]─╮`, `  ✅ Generated: ${files[0].name}`, '╰──────────────────╯', '```'].join('\n'), files: [att] });
      } else {
        const { default: archiver } = await import('archiver');
        const zipPath = path.join(tmpDir, 'generated.zip');
        await new Promise((res, rej) => {
          const output = fs.createWriteStream(zipPath);
          const archive = archiver('zip');
          archive.pipe(output);
          files.forEach(f => archive.file(path.join(tmpDir, f.name), { name: f.name }));
          archive.finalize();
          output.on('close', res); archive.on('error', rej);
        });
        const att = new MessageAttachment(zipPath, 'generated.zip');
        await waitMsg.edit({ content: ['```', `╭─[ CODE AGENT ]─╮`, `  ✅ ${files.length} files generated`, ...files.map(f=>`  📄 ${f.name}`), '╰──────────────────╯', '```'].join('\n'), files: [att] });
        setTimeout(() => fs.rmSync(tmpDir, { recursive: true, force: true }), 10000);
      }
    } catch (err) {
      console.error('[Code Agent]:', err);
      await waitMsg.edit(`\`\`\`\n❌ Code Agent Error: ${err.message}\n\`\`\``);
    }
  }
};
