/**
 * commands/utility/streamqueue.js
 * Queue URLs/filenames to stream sequentially.
 * Supports both !stream (download) and !stream-nd (direct) modes per item.
 *
 * Usage:
 *   !streamqueue add <url|filename>
 *   !streamqueue add-nd <url>        ← no-download mode for this item
 *   !streamqueue list
 *   !streamqueue skip
 *   !streamqueue clear
 */

import path from 'path';
import { startStream, startStreamNd, isYtdlpUrl, VIDEO_DIR } from '../../functions/streamUtils.js';
import streamManager, { StreamSession } from '../../functions/streamManager.js';

const queues = new Map(); // guildId → Array<{ item: string, nd: boolean }>

async function playNext(client, guildId, channelId, textChannel) {
  const queue = queues.get(guildId) ?? [];

  if (!queue.length) {
    await streamManager.destroy(guildId, client).catch(() => {});
    textChannel.send([
      '```',
      '╭─[ QUEUE ENDED ]───────────────────╮',
      '  📭 No more items.',
      '╰──────────────────────────────────╯',
      '```',
    ].join('\n')).catch(() => {});
    return;
  }

  const { item, nd } = queue.shift();
  queues.set(guildId, queue);

  // Resolve bare filename to ./video/<n>
  let source = item;
  if (!isYtdlpUrl(item) && !item.startsWith('http') && !path.isAbsolute(item)) {
    source = path.join(VIDEO_DIR, item);
  }

  await streamManager.destroy(guildId, client).catch(() => {});
  textChannel.send(`\`\`\`\n⏳ Loading${nd ? ' (direct)' : ''}: ${item}\n\`\`\``).catch(() => {});

  try {
    const fn = nd ? startStreamNd : startStream;
    const { streamer, command, title, done } = await fn(client, guildId, channelId, source);

    const s       = new StreamSession(guildId);
    s.channelId   = channelId;
    s.url         = source;
    s.title       = title;
    s.streamer    = streamer;
    s.command     = command;
    s.textChannel = textChannel;
    streamManager.set(guildId, s);

    textChannel.send([
      '```',
      '╭─[ QUEUE → NOW PLAYING ]───────────╮',
      `  📺 ${title}`,
      `  ${nd ? '⚡ Direct' : '💾 Downloaded'} · 📷 Camera · 480p · 24fps`,
      `  📋 Remaining: ${queue.length}`,
      '╰──────────────────────────────────╯',
      '```',
    ].join('\n')).catch(() => {});

    done
      .then(() => { if (streamManager.has(guildId)) playNext(client, guildId, channelId, textChannel); })
      .catch(() => setTimeout(() => playNext(client, guildId, channelId, textChannel), 2000));

  } catch (err) {
    console.error('[streamqueue]', err);
    textChannel.send(`\`\`\`\n❌ ${err.message} — skipping\n\`\`\``).catch(() => {});
    setTimeout(() => playNext(client, guildId, channelId, textChannel), 2000);
  }
}

export default {
  name:        'streamqueue',
  aliases:     ['sq', 'camqueue'],
  category:    'utility',
  description: 'Queue videos/URLs to stream sequentially',
  usage:       'streamqueue <add|add-nd|list|clear|skip> [url or filename]',

  async execute(message, args, client) {
    if (!message.guild) return message.channel.send('```\n❌ Server only.\n```');

    const guildId = message.guild.id;
    const sub     = (args[0] ?? '').toLowerCase();

    if (sub === 'add' || sub === 'add-nd') {
      const nd   = sub === 'add-nd';
      const item = args.slice(1).join(' ');
      if (!item) return message.channel.send(`\`\`\`\n❌ Usage: streamqueue ${sub} <url|filename>\n\`\`\``);

      if (!queues.has(guildId)) queues.set(guildId, []);
      queues.get(guildId).push({ item, nd });
      const pos = queues.get(guildId).length;

      if (!streamManager.has(guildId)) {
        const vc = message.member?.voice?.channel;
        if (!vc) return message.channel.send('```\n❌ Join a voice channel first.\n```');
        if (message.deletable) message.delete().catch(() => {});
        return playNext(client, guildId, vc.id, message.channel);
      }

      await message.channel.send(`\`\`\`\n✅ Added${nd ? ' (direct)' : ''} (pos ${pos}): ${item}\n\`\`\``);

    } else if (sub === 'list') {
      const cur   = streamManager.get(guildId);
      const queue = queues.get(guildId) ?? [];
      const lines = ['```', '╭─[ STREAM QUEUE ]──────────────────╮'];
      lines.push(cur ? `  📺 Now: ${cur.title ?? cur.url}` : '  ⏹️  Nothing playing.');
      if (queue.length) {
        lines.push('');
        queue.forEach(({ item, nd }, i) => lines.push(`  ${i + 1}. ${nd ? '[direct] ' : ''}${item}`));
      } else lines.push('  📭 Queue empty.');
      lines.push('╰──────────────────────────────────╯', '```');
      await message.channel.send(lines.join('\n'));

    } else if (sub === 'clear') {
      queues.set(guildId, []);
      await message.channel.send('```\n🗑️  Queue cleared.\n```');

    } else if (sub === 'skip') {
      const cur = streamManager.get(guildId);
      if (!cur) return message.channel.send('```\n❌ Nothing playing.\n```');
      const { channelId, textChannel } = cur;
      await streamManager.destroy(guildId, client).catch(() => {});
      await message.channel.send('```\n⏭️  Skipping...\n```');
      playNext(client, guildId, channelId, textChannel ?? message.channel);

    } else {
      await message.channel.send([
        '```',
        '  !sq add <url|file>     — add (download mode)',
        '  !sq add-nd <url>       — add (direct/no-download)',
        '  !sq list               — show queue',
        '  !sq clear              — clear queue',
        '  !sq skip               — skip current',
        '```',
      ].join('\n'));
    }

    if (message.deletable) message.delete().catch(() => {});
  },
};
