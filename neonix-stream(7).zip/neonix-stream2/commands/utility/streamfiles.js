/**
 * commands/utility/streamfiles.js
 * List all videos in ./video/.
 */

import { listLocalVideos } from '../../functions/streamUtils.js';

export default {
  name:        'streamfiles',
  aliases:     ['videolist', 'vlist', 'videos'],
  category:    'utility',
  description: 'List downloaded videos in ./video/',
  usage:       'streamfiles',

  async execute(message) {
    const files = listLocalVideos();
    if (!files.length) {
      return message.channel.send([
        '```',
        '╭─[ VIDEO FOLDER ]──────────────────╮',
        '  📭 No videos yet.',
        '  Use !stream <yt url> to download one.',
        '╰──────────────────────────────────╯',
        '```',
      ].join('\n'));
    }
    const list = files
      .map((f, i) => `  ${i + 1}. ${f.name}  (${(f.size / 1024 / 1024).toFixed(1)} MB)`)
      .join('\n');
    await message.channel.send([
      '```',
      '╭─[ VIDEO FOLDER ]──────────────────╮',
      list,
      '',
      '  !streamlocal <filename>  to stream',
      '╰──────────────────────────────────╯',
      '```',
    ].join('\n'));
    if (message.deletable) message.delete().catch(() => {});
  },
};
