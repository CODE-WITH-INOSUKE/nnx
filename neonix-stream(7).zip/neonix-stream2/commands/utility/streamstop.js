/**
 * commands/utility/streamstop.js
 */

import streamManager from '../../functions/streamManager.js';

export default {
  name:        'streamstop',
  aliases:     ['glstop', 'camstop', 'endstream'],
  category:    'utility',
  description: 'Stop the active stream and leave voice',
  usage:       'streamstop',

  async execute(message, args, client) {
    if (!message.guild) return message.channel.send('```\n❌ Server only.\n```');
    const guildId = message.guild.id;
    if (!streamManager.has(guildId)) {
      return message.channel.send('```\n❌ No active stream.\n```');
    }
    const s = streamManager.get(guildId);
    const t = s.title ?? s.url;
    await streamManager.destroy(guildId, client);
    await message.channel.send([
      '```',
      '╭─[ STOPPED ]───────────────────────╮',
      `  📺 ${t}`,
      '  ⏹️  Stopped · 👋 Left voice',
      '╰──────────────────────────────────╯',
      '```',
    ].join('\n'));
    if (message.deletable) message.delete().catch(() => {});
  },
};
