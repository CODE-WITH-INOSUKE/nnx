/**
 * commands/utility/stream-nd.js
 * Stream a YouTube video DIRECTLY without downloading.
 * Uses yt-dlp -g to get the direct CDN URL, passes it straight to ffmpeg.
 * Usage: !stream-nd <youtube url>
 */

import { startStreamNd, isYtdlpUrl } from '../../functions/streamUtils.js';
import streamManager, { StreamSession } from '../../functions/streamManager.js';

export default {
  name:        'stream-nd',
  aliases:     ['streamnd', 'glnd', 'camnd', 'streamdirect'],
  category:    'utility',
  description: 'Stream YouTube video directly without downloading (no-download mode)',
  usage:       'stream-nd <youtube url>',

  async execute(message, args, client) {
    if (!message.guild) return message.channel.send('```\n❌ Server only.\n```');
    const vc = message.member?.voice?.channel;
    if (!vc) return message.channel.send('```\n❌ Join a voice channel first.\n```');

    if (!args.length) {
      return message.channel.send([
        '```',
        'Usage: !stream-nd <youtube url>',
        '',
        '  Streams directly without saving to disk.',
        '  Use !stream for download-then-stream mode.',
        '```',
      ].join('\n'));
    }

    const url     = args[0];
    const guildId = message.guild.id;

    if (!isYtdlpUrl(url) && !url.startsWith('http')) {
      return message.channel.send('```\n❌ Provide a YouTube or direct video URL.\n```');
    }

    if (streamManager.has(guildId)) await streamManager.destroy(guildId, client);

    const statusMsg = await message.channel.send([
      '```',
      '╭─[ STREAM-ND ]─────────────────────╮',
      '  🔗 Resolving direct URL...',
      '╰──────────────────────────────────╯',
      '```',
    ].join('\n'));

    try {
      const { streamer, command, title, done } = await startStreamNd(
        client, guildId, vc.id, url
      );

      const session       = new StreamSession(guildId);
      session.channelId   = vc.id;
      session.url         = url;
      session.title       = title;
      session.streamer    = streamer;
      session.command     = command;
      session.textChannel = message.channel;
      streamManager.set(guildId, session);

      done.then(async () => {
        if (!streamManager.has(guildId)) return;
        const s = streamManager.get(guildId);
        await streamManager.destroy(guildId, client);
        message.channel.send([
          '```',
          '╭─[ STREAM ENDED ]──────────────────╮',
          `  📺 ${s?.title ?? url}`,
          '  ✅ Finished.',
          '╰──────────────────────────────────╯',
          '```',
        ].join('\n')).catch(() => {});
      }).catch(() => {});

      await statusMsg.edit([
        '```',
        '╭─[ STREAMING (NO DOWNLOAD) ]───────╮',
        `  📺 ${title}`,
        `  🔊 ${vc.name}`,
        '  📡 Go Live · 480p · 24fps',
        '  ⚡ Direct stream mode',
        '',
        '  !streamstop  — stop & leave VC',
        '  !streamnp    — stream info',
        '╰──────────────────────────────────╯',
        '```',
      ].join('\n'));

    } catch (err) {
      console.error('[stream-nd]', err);
      await streamManager.destroy(guildId, client).catch(() => {});
      await statusMsg.edit(`\`\`\`\n❌ ${err.message}\n\`\`\``);
    }

    if (message.deletable) message.delete().catch(() => {});
  },
};
